@echo off
chcp 65001 >nul
title OSFY - Sistema de Precos
color 0A
cls

echo.
echo  ========================================================
echo.
echo            OSFY - SISTEMA DE PRECOS
echo           Iniciando o sistema...
echo.
echo  ========================================================
echo.

cd /d "%~dp0"

:: Verifica se Node.js esta instalado
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo  ERRO: Node.js nao esta instalado!
    echo  Execute INSTALAR.bat primeiro.
    echo.
    pause
    exit /b 1
)

:: Verifica se node_modules existe
if not exist "node_modules" (
    echo  Dependencias nao encontradas!
    echo  Execute INSTALAR.bat primeiro.
    echo.
    pause
    exit /b 1
)

echo  Iniciando servidor...
echo.
echo  Painel: http://localhost:3000
echo.
echo  ========================================================
echo.

node server.js

pause
