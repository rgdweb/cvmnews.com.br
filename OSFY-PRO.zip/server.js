/**
 * ============================================
 * 📱 OSFY - SISTEMA DE PREÇOS
 * ============================================
 * Inteligente e Resposta Rápida 🚀
 */

const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");
const fs = require("fs");
const QRCode = require("qrcode");
const { Client, LocalAuth } = require("whatsapp-web.js");

// =====================================
// SISTEMA DE LICENÇA
// =====================================
const licenseValidator = require("./license-system/license-validator");
const { LICENSE_STATUS } = licenseValidator;

let licenseStatus = null;
let licenseInfo = null;

function checkLicense() {
  const result = licenseValidator.validateLicense();
  licenseStatus = result.status;
  licenseInfo = result;
  
  const statusMessages = {
    [LICENSE_STATUS.VALID]: 'Licenca valida',
    [LICENSE_STATUS.TRIAL]: `Trial: ${result.daysRemaining} dias restantes`,
    [LICENSE_STATUS.TRIAL_EXPIRED]: 'Trial expirado',
    [LICENSE_STATUS.INVALID]: 'Licenca invalida',
    [LICENSE_STATUS.EXPIRED]: 'Licenca expirada',
    [LICENSE_STATUS.HARDWARE_MISMATCH]: 'Hardware nao corresponde',
    [LICENSE_STATUS.CPF_MISMATCH]: 'CPF nao corresponde',
    [LICENSE_STATUS.NOT_FOUND]: 'Sem licenca',
    [LICENSE_STATUS.CORRUPTED]: 'Licenca corrompida'
  };
  
  console.log(`\n Licenca: ${statusMessages[licenseStatus] || 'Desconhecido'}`);
  if (result.clientCPF) console.log(`   CPF vinculado: ${result.clientCPF}`);
  if (result.plano) console.log(`   Plano: ${result.planoNome || result.plano}`);
  if (result.features) console.log(`   Multi-empresa: ${result.features.multiEmpresa ? 'SIM' : 'NAO'}`);
  console.log('');
  
  return result;
}

// Verifica licença ao iniciar
checkLicense();

// =====================================
// CONFIGURAÇÕES
// =====================================
const PORT = 3000;
const TELAS_FILE = path.join(__dirname, "telas.json");
const BACKUP_DIR = path.join(__dirname, "backups");

if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

// =====================================
// ESTADO GLOBAL
// =====================================
let whatsappClient = null;
let whatsappConectado = false;
let io = null;
let dadosTelas = null;
let botAtivo = true; // Bot começa ativo
let modoTeste = false; // Modo teste desativado por padrão
let numerosTeste = []; // Números autorizados para teste

const clientesPausados = new Set();

const estatisticas = {
  consultasHoje: 0,
  mensagensRecebidas: 0,
  inicio: new Date().toISOString()
};

// =====================================
// PROTEÇÃO ANTI-BLOQUEIO (RATE LIMITER)
// =====================================
const rateLimiter = {
  mensagens: new Map(), // numero -> { count, resetTime }
  limitePorMinuto: 5,   // Máximo 5 mensagens por minuto por número
  limiteGlobalMinuto: 30, // Máximo 30 mensagens por minuto total
  mensagensGlobal: { count: 0, resetTime: Date.now() + 60000 },
  delayEntreMsgs: 2000, // 2 segundos entre mensagens
  ultimaMsg: 0
};

// Verifica se pode enviar mensagem (rate limiting)
function podeEnviarMensagem(from) {
  const agora = Date.now();
  
  // Limpa registros antigos
  if (agora > rateLimiter.mensagensGlobal.resetTime) {
    rateLimiter.mensagensGlobal = { count: 0, resetTime: agora + 60000 };
  }
  
  // Verifica limite global
  if (rateLimiter.mensagensGlobal.count >= rateLimiter.limiteGlobalMinuto) {
    return { pode: false, motivo: 'Limite global de mensagens atingido' };
  }
  
  // Verifica limite por número
  if (!rateLimiter.mensagens.has(from)) {
    rateLimiter.mensagens.set(from, { count: 0, resetTime: agora + 60000 });
  }
  
  const registro = rateLimiter.mensagens.get(from);
  if (agora > registro.resetTime) {
    registro.count = 0;
    registro.resetTime = agora + 60000;
  }
  
  if (registro.count >= rateLimiter.limitePorMinuto) {
    return { pode: false, motivo: 'Limite por número atingido' };
  }
  
  // Verifica delay entre mensagens
  if (agora - rateLimiter.ultimaMsg < rateLimiter.delayEntreMsgs) {
    return { pode: false, motivo: 'Aguarde um momento' };
  }
  
  return { pode: true };
}

// Registra envio de mensagem
function registrarEnvio(from) {
  rateLimiter.ultimaMsg = Date.now();
  rateLimiter.mensagensGlobal.count++;
  
  const registro = rateLimiter.mensagens.get(from);
  if (registro) {
    registro.count++;
  }
}

// =====================================
// LOGGER
// =====================================
function log(nivel, categoria, mensagem) {
  const timestamp = new Date().toISOString();
  const cores = { INFO: '\x1b[36m', WARN: '\x1b[33m', ERRO: '\x1b[31m', SUCESSO: '\x1b[32m' };
  console.log(`${cores[nivel] || ''}[${timestamp}] [${categoria}] ${mensagem}\x1b[0m`);
}

// =====================================
// BACKUP
// =====================================
function criarBackup() {
  try {
    if (!dadosTelas) return;
    const nome = `telas_${Date.now()}.json`;
    fs.writeFileSync(path.join(BACKUP_DIR, nome), JSON.stringify(dadosTelas, null, 2));
    const backups = fs.readdirSync(BACKUP_DIR).sort().reverse();
    backups.slice(10).forEach(b => fs.unlinkSync(path.join(BACKUP_DIR, b)));
    log('INFO', 'BACKUP', `Backup criado: ${nome}`);
  } catch (e) {}
}

// =====================================
// CARREGAR/SALVAR
// =====================================
function carregarDados() {
  try {
    if (fs.existsSync(TELAS_FILE)) {
      dadosTelas = JSON.parse(fs.readFileSync(TELAS_FILE, "utf8"));
      // Carregar estado do bot
      if (dadosTelas.botAtivo !== undefined) botAtivo = dadosTelas.botAtivo;
      // Carregar modo teste
      if (dadosTelas.modoTeste !== undefined) modoTeste = dadosTelas.modoTeste;
      // Carregar números de teste
      if (dadosTelas.numerosTeste) numerosTeste = dadosTelas.numerosTeste;
      // Inicializar estrutura de empresas se não existir
      if (!dadosTelas.empresas) {
        dadosTelas.empresas = [{
          id: 'default',
          nome: dadosTelas.empresa?.nome || 'Empresa Principal',
          ativo: true,
          criadoEm: new Date().toISOString()
        }];
      }
      // Inicializar empresaAtual se não existir
      if (!dadosTelas.empresaAtual) {
        dadosTelas.empresaAtual = 'default';
      }
      // Garantir que cada tela tem empresaId
      if (dadosTelas.telas) {
        dadosTelas.telas = dadosTelas.telas.map(t => ({
          ...t,
          empresaId: t.empresaId || 'default'
        }));
      }
      log('SUCESSO', 'DADOS', `${dadosTelas.telas?.length || 0} telas carregadas | ${dadosTelas.empresas?.length || 1} empresa(s) | Modo Teste: ${modoTeste ? 'ON' : 'OFF'}`);
      return true;
    }
  } catch (e) {
    log('ERRO', 'DADOS', 'Erro ao carregar: ' + e.message);
  }
  dadosTelas = { 
    empresa: {}, 
    telas: [], 
    empresas: [{
      id: 'default',
      nome: 'Empresa Principal',
      ativo: true,
      criadoEm: new Date().toISOString()
    }],
    empresaAtual: 'default'
  };
  return false;
}

function salvarDados() {
  try {
    dadosTelas.botAtivo = botAtivo;
    dadosTelas.modoTeste = modoTeste;
    dadosTelas.numerosTeste = numerosTeste;
    fs.writeFileSync(TELAS_FILE, JSON.stringify(dadosTelas, null, 2));
    criarBackup();
  } catch (e) {
    log('ERRO', 'DADOS', 'Erro ao salvar: ' + e.message);
  }
}

carregarDados();

// =====================================
// VERIFICAR LIMITES DO PLANO
// =====================================
function verificarLimitesPlano() {
  if (!licenseInfo?.features) return;
  
  const features = licenseInfo.features;
  
  // Verificar limite de produtos
  const totalProdutos = dadosTelas.telas?.length || 0;
  if (features.maxProdutos > 0 && totalProdutos > features.maxProdutos) {
    log('WARN', 'LICENCA', `Limite de produtos excedido: ${totalProdutos}/${features.maxProdutos}`);
  }
  
  // Verificar limite de empresas
  const totalEmpresas = dadosTelas.empresas?.length || 1;
  if (features.maxEmpresas > 0 && features.maxEmpresas < 999 && totalEmpresas > features.maxEmpresas) {
    log('WARN', 'LICENCA', `Limite de empresas excedido: ${totalEmpresas}/${features.maxEmpresas}`);
  }
}

verificarLimitesPlano();

// =====================================
// MARCAS CONHECIDAS (ordem alfabética)
// =====================================
const MARCAS = [
  'alcatel', 'apple', 'asus', 'huawei', 'honor',
  'iphone', 'lenovo', 'lg', 'motorola', 'moto',
  'multilaser', 'nokia', 'oneplus', 'oppo', 'poco',
  'positivo', 'realme', 'redmi', 'samsung', 'tcl',
  'vivo', 'xiaomi', 'zenfone', 'zte'
];

// Mapear variações para marca padrão
const MARCA_ALIASES = {
  'moto': 'motorola',
  'apple': 'iphone',
  'redmi': 'xiaomi',
  'poco': 'xiaomi',
  'zenfone': 'asus',
  'honor': 'huawei'
};

// =====================================
// PALAVRAS PARA IGNORAR (STOPWORDS)
// =====================================
const STOPWORDS = [
  'bom', 'boa', 'dia', 'tarde', 'noite', 'tudo', 'bem', 'ola', 'olá', 'oi', 'oie', 'oii',
  'gostaria', 'queria', 'quero', 'preciso', 'saber', 'valor', 'preço', 'preco', 'quanto',
  'custa', 'fica', 'qual', 'display', 'tela', 'do', 'da', 'de', 'o', 'a', 'os', 'as',
  'um', 'uma', 'para', 'por', 'que', 'se', 'eu', 'voce', 'você', 'me', 'meu', 'minha',
  'tem', 'tenho', 'favor', 'pfv', 'pf', 'porfavor', 'obg', 'obrigado', 'obrigada',
  'ola', 'hi', 'hello', 'hey', 'amigo', 'amiga', 'amigos'
];

// =====================================
// ESTADO DE CLIENTES AGUARDANDO MARCA
// =====================================
const clientesAguardandoMarca = new Map(); // from -> { termo, marcasEncontradas, produtos }

// =====================================
// UTILITÁRIOS
// =====================================
function normalizar(texto) {
  if (!texto) return "";
  return texto
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// Extrair palavras relevantes (remover stopwords e marcas)
function extrairPalavrasRelevantes(texto) {
  const t = normalizar(texto);
  const palavras = t.split(' ').filter(p => p.length > 0);
  
  // Remover stopwords e marcas
  return palavras.filter(p => {
    const isStopword = STOPWORDS.includes(p);
    const isMarca = MARCAS.includes(p);
    return !isStopword && !isMarca;
  });
}

// Detectar marca na mensagem do cliente
function detectarMarcaNaMensagem(texto) {
  const t = normalizar(texto);
  const palavras = t.split(' ');
  
  for (const p of palavras) {
    if (MARCAS.includes(p)) {
      // Normalizar marca (ex: 'moto' -> 'motorola')
      return MARCA_ALIASES[p] || p;
    }
  }
  return null;
}

// Normalizar marca do cadastro
function normalizarMarca(marca) {
  if (!marca) return null;
  const m = normalizar(marca);
  return MARCA_ALIASES[m] || m;
}

// =====================================
// BUSCAR NO BANCO - LÓGICA POR PALAVRAS E MARCAS
// =====================================
function buscarNoBanco(texto) {
  if (!dadosTelas?.telas) return { disponiveis: [], indisponiveis: [], porMarca: {} };
  
  // Extrair palavras relevantes
  const palavras = extrairPalavrasRelevantes(texto);
  
  // Detectar se cliente já informou a marca
  const marcaInformada = detectarMarcaNaMensagem(texto);
  
  const encontrados = [];
  const indisponiveis = [];
  const porMarca = {};
  
  dadosTelas.telas.forEach(tela => {
    const modeloNorm = normalizar(tela.modelo);
    const marcaTela = normalizarMarca(tela.marca) || 'outros';
    
    // Verificar se alguma palavra relevante está no modelo
    const encontrou = palavras.some(p => modeloNorm.includes(p));
    
    if (encontrou) {
      // Se cliente informou marca, filtrar só essa marca
      if (marcaInformada) {
        if (marcaTela !== marcaInformada) return; // Pula se não for a marca
      }
      
      const item = { ...tela, marcaDetectada: marcaTela };
      
      if (tela.ativo && tela.estoque > 0) {
        encontrados.push(item);
        
        // Agrupar por marca
        if (!porMarca[marcaTela]) porMarca[marcaTela] = [];
        porMarca[marcaTela].push(item);
      } else {
        indisponiveis.push(item);
      }
    }
  });
  
  return { 
    disponiveis: encontrados, 
    indisponiveis: indisponiveis,
    porMarca: porMarca,
    marcasEncontradas: Object.keys(porMarca),
    palavrasBuscadas: palavras
  };
}

// =====================================
// FORMATAR RESPOSTA DA TELA
// =====================================
function formatarRespostaTela(tela) {
  const obs = tela.observacao ? ` ${tela.observacao}` : '';
  return `${tela.modelo} ${tela.tipo}${obs}\tR$ ${tela.preco.toFixed(2)}`;
}

// =====================================
// VERIFICAR NÚMERO DE TESTE
// =====================================
function ehNumeroTeste(from) {
  if (!modoTeste) return false;
  if (numerosTeste.length === 0) return false;
  return numerosTeste.includes(from);
}

// =====================================
// VERIFICAR SE MODO TESTE BLOQUEIA NÚMERO
// =====================================
function modoTesteBloqueia(from) {
  // Se modo teste está desativado, não bloqueia ninguém
  if (!modoTeste) return false;
  // Se modo teste está ativo mas não há números cadastrados, não bloqueia
  if (numerosTeste.length === 0) return false;
  // Se modo teste está ativo e o número NÃO está na lista, BLOQUEIA
  return !numerosTeste.includes(from);
}

// =====================================
// HORÁRIO DE ATENDIMENTO (PERSONALIZÁVEL)
// =====================================
function horarioAtendimento() {
  const agora = new Date();
  const hora = agora.getHours();
  const minuto = agora.getMinutes();
  const dia = agora.getDay();
  
  const horaAtual = hora + minuto / 60;
  
  // Usar horário personalizado ou padrão
  const horario = dadosTelas.empresa?.horario || {
    semanaInicio1: 9, semanaFim1: 12,
    semanaInicio2: 13.5, semanaFim2: 18.5,
    sabadoInicio: 9, sabadoFim: 13,
    domingo: false
  };
  
  // Segunda a sexta (1-5)
  if (dia >= 1 && dia <= 5) {
    const turno1 = horaAtual >= horario.semanaInicio1 && horaAtual < horario.semanaFim1;
    const turno2 = horaAtual >= horario.semanaInicio2 && horaAtual < horario.semanaFim2;
    if (turno1 || turno2) return true;
  }
  
  // Sábado (6)
  if (dia === 6) {
    if (horaAtual >= horario.sabadoInicio && horaAtual < horario.sabadoFim) {
      return true;
    }
  }
  
  return false;
}

function getMensagemForaHorario() {
  const emp = dadosTelas.empresa?.nome || "SUA LOJA";
  const tel = dadosTelas.empresa?.telefone || "";
  const cidade = dadosTelas.empresa?.cidade || "";
  const horario = dadosTelas.empresa?.horario || {
    semanaInicio1: 9, semanaFim1: 12,
    semanaInicio2: 13.5, semanaFim2: 18.5,
    sabadoInicio: 9, sabadoFim: 13
  };
  
  // Formatar horários
  const formatarHora = (h) => {
    const horas = Math.floor(h);
    const minutos = Math.round((h - horas) * 60);
    return `${horas.toString().padStart(2, '0')}:${minutos.toString().padStart(2, '0')}`;
  };
  
  const horarioStr = `📅 Segunda a sexta: ${formatarHora(horario.semanaInicio1)} às ${formatarHora(horario.semanaFim1)} e ${formatarHora(horario.semanaInicio2)} às ${formatarHora(horario.semanaFim2)}
📅 Sábados: ${formatarHora(horario.sabadoInicio)} às ${formatarHora(horario.sabadoFim)}`;
  
  let contato = '';
  if (tel) contato = `\n📞 Telefone: ${tel}`;
  if (cidade) contato += `\n📍 ${cidade}`;
  
  return `👋 Olá! Seja bem-vindo(a) à ${emp} 📱🔧

No momento estamos fechados/indisponíveis ⏰

🕘 Nosso horário de atendimento:
${horarioStr}${contato}

💬 Assim que retornarmos ao nosso horário de atendimento, responderemos todas as mensagens com atenção 😊

🙏 Agradecemos o contato e a preferência!`;
}

// =====================================
// EXPRESS
// =====================================
const app = express();
const server = http.createServer(app);
io = new Server(server);

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// API - Dados da empresa (retorna dados da empresa atual ou específica)
app.get("/api/empresa", (req, res) => {
  const empresaAtualId = dadosTelas.empresaAtual || 'default';
  const empresa = (dadosTelas.empresas || []).find(e => e.id === empresaAtualId);
  
  // Retornar dados da empresa atual com fallback para dadosTelas.empresa
  const dadosEmpresa = {
    ...(dadosTelas.empresa || {}),
    ...(empresa || {}),
    empresaId: empresaAtualId
  };
  
  res.json(dadosEmpresa);
});

app.post("/api/empresa", (req, res) => {
  const empresaAtualId = dadosTelas.empresaAtual || 'default';
  
  // Atualizar dadosTelas.empresa (legado)
  dadosTelas.empresa = { ...dadosTelas.empresa, ...req.body };
  
  // Também atualizar na lista de empresas
  const idx = (dadosTelas.empresas || []).findIndex(e => e.id === empresaAtualId);
  if (idx >= 0) {
    dadosTelas.empresas[idx] = {
      ...dadosTelas.empresas[idx],
      ...req.body,
      atualizadoEm: new Date().toISOString()
    };
  }
  
  salvarDados();
  io.emit("dados_atualizados", { ...dadosTelas, botAtivo });
  res.json({ ok: true });
});

// API - Toggle Bot (Ativar/Desativar)
app.post("/api/bot/toggle", (req, res) => {
  botAtivo = !botAtivo;
  salvarDados();
  io.emit("bot_status", botAtivo);
  io.emit("dados_atualizados", { ...dadosTelas, botAtivo });
  log('INFO', 'BOT', botAtivo ? 'Bot ATIVADO (Online)' : 'Bot DESATIVADO (Offline)');
  res.json({ ativo: botAtivo });
});

// API - Status do Bot
app.get("/api/bot/status", (req, res) => {
  res.json({ ativo: botAtivo, modoTeste, numerosTeste });
});

// API - Toggle Modo Teste
app.post("/api/teste/toggle", (req, res) => {
  modoTeste = !modoTeste;
  salvarDados();
  io.emit("modo_teste_status", { modoTeste, numerosTeste });
  log('INFO', 'TESTE', modoTeste ? 'Modo Teste ATIVADO' : 'Modo Teste DESATIVADO');
  res.json({ modoTeste, numerosTeste });
});

// API - Adicionar número de teste
app.post("/api/teste/numero", (req, res) => {
  const numero = req.body.numero?.trim();
  if (!numero) return res.status(400).json({ erro: "Número obrigatório" });
  
  // Formatar número (adicionar @c.us se não tiver)
  const numeroFormatado = numero.includes('@') ? numero : numero + '@c.us';
  
  if (!numerosTeste.includes(numeroFormatado)) {
    numerosTeste.push(numeroFormatado);
    salvarDados();
    io.emit("modo_teste_status", { modoTeste, numerosTeste });
    log('INFO', 'TESTE', `Número adicionado: ${numero}`);
  }
  
  res.json({ modoTeste, numerosTeste });
});

// API - Remover número de teste
app.delete("/api/teste/numero/:numero", (req, res) => {
  const numero = req.params.numero;
  numerosTeste = numerosTeste.filter(n => n !== numero);
  salvarDados();
  io.emit("modo_teste_status", { modoTeste, numerosTeste });
  log('INFO', 'TESTE', `Número removido: ${numero}`);
  res.json({ modoTeste, numerosTeste });
});

// API - Listar números de teste
app.get("/api/teste/numeros", (req, res) => {
  res.json({ modoTeste, numerosTeste });
});

// API - Listar telas (COM FILTRO POR EMPRESA)
app.get("/api/telas", (req, res) => {
  const telas = dadosTelas.telas || [];
  const { busca, ativo, empresaId, todas } = req.query;
  
  let resultado = telas;
  
  // Se não especificado "todas", filtrar por empresa atual
  if (todas !== 'true') {
    const filtroEmpresaId = empresaId || dadosTelas.empresaAtual || 'default';
    resultado = resultado.filter(t => t.empresaId === filtroEmpresaId || !t.empresaId);
  } else if (empresaId) {
    // Se especificou empresaId específica
    resultado = resultado.filter(t => t.empresaId === empresaId || !t.empresaId);
  }
  
  if (busca) {
    const buscaNorm = normalizar(busca);
    resultado = resultado.filter(t => 
      normalizar(t.modelo).includes(buscaNorm) ||
      normalizar(t.tipo).includes(buscaNorm)
    );
  }
  
  if (ativo !== undefined) {
    resultado = resultado.filter(t => t.ativo === (ativo === 'true'));
  }
  
  res.json(resultado);
});

// API - Adicionar tela (COM VERIFICACAO DE LIMITE)
app.post("/api/telas", (req, res) => {
  // Verificar limite de produtos (por empresa atual ou total)
  const empresaAtualId = dadosTelas.empresaAtual || 'default';
  const telasEmpresaAtual = (dadosTelas.telas || []).filter(t => t.empresaId === empresaAtualId);
  const limiteCheck = licenseValidator.checkProductLimit(telasEmpresaAtual.length);
  
  if (!limiteCheck.allowed) {
    return res.status(403).json({ 
      erro: 'Limite de produtos atingido para esta empresa',
      max: limiteCheck.max,
      atual: limiteCheck.current,
      empresa: empresaAtualId,
      solucao: 'Faça upgrade para o plano PRO ou PREMIUM'
    });
  }
  
  const nova = {
    id: Date.now().toString(),
    modelo: req.body.modelo || "",
    marca: req.body.marca || "",
    tipo: req.body.tipo || "",
    observacao: req.body.observacao || "",
    preco: parseFloat(req.body.preco) || 0,
    estoque: parseInt(req.body.estoque) || 0,
    ativo: req.body.ativo !== false,
    empresaId: req.body.empresaId || empresaAtualId // Usar empresa atual como padrão
  };
  
  dadosTelas.telas.push(nova);
  salvarDados();
  
  io.emit("tela_adicionada", nova);
  io.emit("stats", { total: dadosTelas.telas.length, ativos: dadosTelas.telas.filter(t => t.ativo).length });
  
  res.json(nova);
});

// API - Atualizar tela
app.put("/api/telas/:id", (req, res) => {
  const idx = dadosTelas.telas.findIndex(t => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ erro: "Tela não encontrada" });
  
  dadosTelas.telas[idx] = {
    ...dadosTelas.telas[idx],
    ...req.body,
    id: req.params.id
  };
  
  salvarDados();
  io.emit("tela_atualizada", dadosTelas.telas[idx]);
  
  res.json(dadosTelas.telas[idx]);
});

// API - Deletar tela
app.delete("/api/telas/:id", (req, res) => {
  const idx = dadosTelas.telas.findIndex(t => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ erro: "Tela não encontrada" });
  
  dadosTelas.telas.splice(idx, 1);
  salvarDados();
  
  io.emit("tela_removida", req.params.id);
  
  res.json({ ok: true });
});

// API - Toggle ativo
app.post("/api/telas/:id/toggle", (req, res) => {
  const tela = dadosTelas.telas.find(t => t.id === req.params.id);
  if (!tela) return res.status(404).json({ erro: "Tela não encontrada" });
  
  tela.ativo = !tela.ativo;
  salvarDados();
  
  io.emit("tela_atualizada", tela);
  
  res.json(tela);
});

// API - Estatísticas
app.get("/api/stats", (req, res) => {
  const telas = dadosTelas.telas || [];
  res.json({
    total: telas.length,
    ativos: telas.filter(t => t.ativo).length,
    inativos: telas.filter(t => !t.ativo).length,
    semEstoque: telas.filter(t => t.estoque === 0).length,
    consultasHoje: estatisticas.consultasHoje,
    mensagensRecebidas: estatisticas.mensagensRecebidas,
    conectado: whatsappConectado,
    botAtivo: botAtivo
  });
});

// API - Marcas disponíveis
app.get("/api/marcas", (req, res) => {
  res.json(MARCAS);
});

// =====================================
// APIs MULTI-EMPRESA
// =====================================

// API - Listar empresas
app.get("/api/empresas", (req, res) => {
  const empresas = dadosTelas.empresas || [];
  const empresaAtual = dadosTelas.empresaAtual || 'default';
  
  // Adicionar contagem de produtos por empresa
  const empresasComContagem = empresas.map(emp => {
    const produtosCount = (dadosTelas.telas || []).filter(t => t.empresaId === emp.id).length;
    return {
      ...emp,
      totalProdutos: produtosCount
    };
  });
  
  res.json({
    empresas: empresasComContagem,
    empresaAtual: empresaAtual,
    multiEmpresaAtivo: licenseInfo?.features?.multiEmpresa || false,
    maxEmpresas: licenseInfo?.features?.maxEmpresas || 1
  });
});

// API - Criar nova empresa (com verificação de limite)
app.post("/api/empresas", (req, res) => {
  const { nome } = req.body;
  
  if (!nome || !nome.trim()) {
    return res.status(400).json({ erro: "Nome da empresa é obrigatório" });
  }
  
  // Verificar se tem feature de multi-empresa
  const features = licenseInfo?.features;
  if (!features?.multiEmpresa && features?.maxEmpresas <= 1) {
    return res.status(403).json({ 
      erro: 'Seu plano não suporta multi-empresa',
      solucao: 'Faça upgrade para o plano PREMIUM para gerenciar múltiplas empresas'
    });
  }
  
  // Verificar limite de empresas
  const empresasAtuais = (dadosTelas.empresas || []).length;
  const limiteCheck = licenseValidator.checkEmpresaLimit(empresasAtuais);
  
  if (!limiteCheck.allowed) {
    return res.status(403).json({ 
      erro: 'Limite de empresas atingido',
      max: limiteCheck.max,
      atual: limiteCheck.current,
      solucao: 'Entre em contato para upgrade do plano'
    });
  }
  
  // Criar nova empresa
  const novaEmpresa = {
    id: 'emp_' + Date.now(),
    nome: nome.trim(),
    ativo: true,
    criadoEm: new Date().toISOString()
  };
  
  if (!dadosTelas.empresas) {
    dadosTelas.empresas = [];
  }
  
  dadosTelas.empresas.push(novaEmpresa);
  salvarDados();
  
  io.emit("empresa_adicionada", novaEmpresa);
  log('SUCESSO', 'EMPRESA', `Nova empresa criada: ${nome}`);
  
  res.json(novaEmpresa);
});

// API - Atualizar empresa
app.put("/api/empresas/:id", (req, res) => {
  const { id } = req.params;
  const { nome, ativo } = req.body;
  
  const idx = (dadosTelas.empresas || []).findIndex(e => e.id === id);
  if (idx === -1) {
    return res.status(404).json({ erro: "Empresa não encontrada" });
  }
  
  // Não permitir desativar a empresa default
  if (id === 'default' && ativo === false) {
    return res.status(400).json({ erro: "Não é possível desativar a empresa principal" });
  }
  
  dadosTelas.empresas[idx] = {
    ...dadosTelas.empresas[idx],
    ...(nome && { nome: nome.trim() }),
    ...(ativo !== undefined && { ativo }),
    atualizadoEm: new Date().toISOString()
  };
  
  salvarDados();
  io.emit("empresa_atualizada", dadosTelas.empresas[idx]);
  
  res.json(dadosTelas.empresas[idx]);
});

// API - Deletar empresa (apenas se não for default e não tiver produtos)
app.delete("/api/empresas/:id", (req, res) => {
  const { id } = req.params;
  
  // Não permitir deletar empresa default
  if (id === 'default') {
    return res.status(400).json({ erro: "Não é possível deletar a empresa principal" });
  }
  
  const idx = (dadosTelas.empresas || []).findIndex(e => e.id === id);
  if (idx === -1) {
    return res.status(404).json({ erro: "Empresa não encontrada" });
  }
  
  // Verificar se tem produtos vinculados
  const produtosVinculados = (dadosTelas.telas || []).filter(t => t.empresaId === id);
  if (produtosVinculados.length > 0) {
    return res.status(400).json({ 
      erro: "Não é possível deletar empresa com produtos vinculados",
      produtosVinculados: produtosVinculados.length,
      solucao: "Mova ou delete os produtos antes de excluir a empresa"
    });
  }
  
  const removida = dadosTelas.empresas.splice(idx, 1)[0];
  
  // Se empresa atual for a removida, voltar para default
  if (dadosTelas.empresaAtual === id) {
    dadosTelas.empresaAtual = 'default';
  }
  
  salvarDados();
  io.emit("empresa_removida", id);
  log('INFO', 'EMPRESA', `Empresa removida: ${removida.nome}`);
  
  res.json({ ok: true, removida });
});

// API - Selecionar empresa atual
app.post("/api/empresas/selecionar/:id", (req, res) => {
  const { id } = req.params;
  
  const empresa = (dadosTelas.empresas || []).find(e => e.id === id);
  if (!empresa) {
    return res.status(404).json({ erro: "Empresa não encontrada" });
  }
  
  if (!empresa.ativo) {
    return res.status(400).json({ erro: "Esta empresa está inativa" });
  }
  
  dadosTelas.empresaAtual = id;
  salvarDados();
  
  io.emit("empresa_selecionada", empresa);
  
  res.json({ ok: true, empresaAtual: empresa });
});

// API - Mover produtos entre empresas
app.post("/api/empresas/mover-produtos", (req, res) => {
  const { deEmpresaId, paraEmpresaId } = req.body;
  
  // Verificar feature de multi-empresa
  if (!licenseInfo?.features?.multiEmpresa) {
    return res.status(403).json({ 
      erro: 'Seu plano não suporta mover produtos entre empresas',
      solucao: 'Faça upgrade para o plano PREMIUM'
    });
  }
  
  if (!deEmpresaId || !paraEmpresaId) {
    return res.status(400).json({ erro: "IDs de origem e destino são obrigatórios" });
  }
  
  // Verificar se empresas existem
  const empresas = dadosTelas.empresas || [];
  const empOrigem = empresas.find(e => e.id === deEmpresaId);
  const empDestino = empresas.find(e => e.id === paraEmpresaId);
  
  if (!empOrigem || !empDestino) {
    return res.status(404).json({ erro: "Empresa de origem ou destino não encontrada" });
  }
  
  // Mover produtos
  let movidos = 0;
  dadosTelas.telas = dadosTelas.telas.map(t => {
    if (t.empresaId === deEmpresaId) {
      movidos++;
      return { ...t, empresaId: paraEmpresaId };
    }
    return t;
  });
  
  salvarDados();
  io.emit("dados_atualizados", { ...dadosTelas, botAtivo });
  
  log('INFO', 'EMPRESA', `${movidos} produtos movidos de "${empOrigem.nome}" para "${empDestino.nome}"`);
  
  res.json({ ok: true, movidos });
});

// WhatsApp - Desconectar
app.post("/api/disconnect", async (req, res) => {
  if (whatsappClient) {
    whatsappConectado = false;
    try { await whatsappClient.destroy(); } catch (e) {}
    whatsappClient = null;
  }
  res.json({ ok: true });
});

// API - Status da Licença (COM FEATURES)
app.get("/api/license", (req, res) => {
  const info = licenseValidator.getActivationInfo();
  const status = licenseValidator.validateLicense();
  
  res.json({
    status: status.status,
    requestCode: info.requestCode,
    clientName: status.clientName || null,
    clientCPF: status.clientCPF || null,
    transferLock: status.transferLock || false,
    daysRemaining: status.daysRemaining || 0,
    expiresAt: status.expiresAt || null,
    isValid: status.status === LICENSE_STATUS.VALID,
    isTrial: status.status === LICENSE_STATUS.TRIAL,
    trialDays: 7,
    version: status.version || '1.0',
    // NOVO: Plano e Features
    plano: status.plano || 'BASICO',
    planoNome: status.planoNome || 'Básico',
    periodo: status.periodo || 'ANUAL',
    features: status.features || {
      maxProdutos: 100,
      maxEmpresas: 1,
      multiEmpresa: false,
      relatorios: false,
      modoTeste: false,
      exportarCSV: false,
      backupAuto: false,
      suporte: 'email',
      apiPersonalizada: false
    }
  });
});

// API - Ativar Licença
app.post("/api/license/activate", (req, res) => {
  const { activationKey } = req.body;
  
  if (!activationKey) {
    return res.status(400).json({ success: false, error: 'Chave de ativação obrigatória' });
  }
  
  const result = licenseValidator.saveLicense(activationKey);
  
  if (result.success) {
    checkLicense(); // Atualiza status
    io.emit('license_status', licenseInfo);
  }
  
  res.json(result);
});

// API - Importar Licença Criptografada
app.post("/api/license/import", (req, res) => {
  const { encryptedLicense } = req.body;
  
  if (!encryptedLicense) {
    return res.status(400).json({ success: false, error: 'Licença obrigatória' });
  }
  
  const result = licenseValidator.importLicense(encryptedLicense);
  
  if (result.success) {
    checkLicense(); // Atualiza status
    io.emit('license_status', licenseInfo);
  }
  
  res.json(result);
});

// Rota principal
app.get("/", (req, res) => {
  // Se licença inválida, mostra página de ativação
  if (licenseStatus !== LICENSE_STATUS.VALID && licenseStatus !== LICENSE_STATUS.TRIAL) {
    return res.sendFile(path.join(__dirname, "public", "activate.html"));
  }
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// =====================================
// WHATSAPP BOT
// =====================================
function initWhatsApp() {
  if (whatsappClient) return;

  whatsappClient = new Client({
    authStrategy: new LocalAuth({ clientId: "telas-bot" }),
    authTimeoutMs: 180000,
    puppeteer: {
      headless: true,
      timeout: 120000,
      args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage", "--disable-gpu"]
    },
  });

  whatsappClient.on("qr", async (qr) => {
    try {
      const img = await QRCode.toDataURL(qr, { width: 300 });
      io.emit("qr", img);
      io.emit("status", { conectado: false, mensagem: "Escaneie o QR Code" });
    } catch (e) {}
  });

  whatsappClient.on("ready", () => {
    whatsappConectado = true;
    io.emit("qr", null);
    io.emit("status", { conectado: true, mensagem: "Conectado!" });
    log('SUCESSO', 'WPP', 'WhatsApp conectado!');
  });

  whatsappClient.on("disconnected", () => {
    whatsappConectado = false;
    io.emit("status", { conectado: false, mensagem: "Desconectado" });
    log('WARN', 'WPP', 'Desconectado');
  });

  whatsappClient.on("message", async (msg) => {
    const from = msg.from || "";
    
    if (from.includes("status") || from.includes("broadcast") || from.includes("@g.us")) return;
    
    try {
      const chat = await msg.getChat();
      if (chat.isGroup) return;
    } catch (e) { return; }
    
    if (msg.timestamp && (Date.now() / 1000 - msg.timestamp) > 300) return;

    const texto = msg.body?.trim() || "";
    if (!texto || texto.length > 500) return;

    // =====================================
    // MODO TESTE - BLOQUEAR NÚMEROS NÃO AUTORIZADOS
    // =====================================
    if (modoTesteBloqueia(from)) {
      log('INFO', 'TESTE', `Mensagem IGNORADA de número não autorizado: ${from.substring(0, 20)}...`);
      return; // Ignora completamente mensagens de números não autorizados
    }

    estatisticas.mensagensRecebidas++;

    await processarMensagem(msg, from, texto);
  });

  whatsappClient.initialize().catch(err => {
    log('ERRO', 'WPP', 'Falha: ' + err.message);
  });
}

// =====================================
// PROCESSAR MENSAGEM
// =====================================

// =====================================
// SAUDAÇÕES HUMANAS
// =====================================
function getSaudacao() {
  const hora = new Date().getHours();
  const saudacoes = {
    manha: ['Bom dia!', 'Olá, bom dia!', 'Bom dia, tudo bem?', 'Oi, bom dia! 👋'],
    tarde: ['Boa tarde!', 'Olá, boa tarde!', 'Boa tarde, tudo bem?', 'Oi, boa tarde! 👋'],
    noite: ['Boa noite!', 'Olá, boa noite!', 'Boa noite, tudo bem?', 'Oi, boa noite! 👋']
  };
  
  let periodo;
  if (hora >= 5 && hora < 12) periodo = 'manha';
  else if (hora >= 12 && hora < 18) periodo = 'tarde';
  else periodo = 'noite';
  
  const lista = saudacoes[periodo];
  return lista[Math.floor(Math.random() * lista.length)];
}

// Saudações para resposta de preço
function getSaudacaoPreco() {
  const saudacoes = [
    'Segue o preço:',
    'Aqui está:',
    'Consultando...',
    'Seguem as opções:',
    'Encontrei isso:',
    'Olha que encontrei:'
  ];
  return saudacoes[Math.floor(Math.random() * saudacoes.length)];
}

// Função segura para enviar mensagens (com rate limiting, delay e "digitando...")
async function enviarMensagemSegura(msg, from, texto, comSaudacao = false) {
  // Verifica rate limiting
  const verificacao = podeEnviarMensagem(from);
  
  if (!verificacao.pode) {
    log('WARN', 'RATE', `Mensagem bloqueada: ${verificacao.motivo}`);
    return false;
  }
  
  try {
    // Pega o chat para mostrar "digitando..."
    const chat = await msg.getChat();
    
    // Se for com saudação, envia em duas partes
    if (comSaudacao) {
      // Primeiro: saudação
      const saudacao = getSaudacao();
      const tempoSaudacao = Math.min(Math.max(saudacao.length / 50, 1), 2);
      
      await chat.sendStateTyping();
      await new Promise(resolve => setTimeout(resolve, tempoSaudacao * 1000));
      await msg.reply(saudacao);
      await chat.clearState();
      
      registrarEnvio(from);
      
      // Pausa entre mensagens (1-2 segundos)
      await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));
      
      // Segundo: a resposta principal
      const tempoDigitacao = Math.min(Math.max(texto.length / 50, 1.5), 4);
      
      await chat.sendStateTyping();
      await new Promise(resolve => setTimeout(resolve, tempoDigitacao * 1000));
      await msg.reply(texto);
      await chat.clearState();
      
      registrarEnvio(from);
    } else {
      // Sem saudação - envio normal com "digitando..."
      const tempoDigitacao = Math.min(Math.max(texto.length / 50, 1.5), 5);
      
      await chat.sendStateTyping();
      await new Promise(resolve => setTimeout(resolve, tempoDigitacao * 1000));
      
      // Delay aleatório extra (0.3s a 0.8s)
      const delayRandom = Math.random() * 0.5 + 0.3;
      await new Promise(resolve => setTimeout(resolve, delayRandom * 1000));
      
      await msg.reply(texto);
      await chat.clearState();
      
      registrarEnvio(from);
    }
    
    return true;
  } catch (e) {
    log('ERRO', 'WPP', 'Erro ao enviar: ' + e.message);
    return false;
  }
}

// Função para enviar resposta de preço com saudação humanizada
async function enviarRespostaPreco(msg, from, texto, encontrou) {
  const verificacao = podeEnviarMensagem(from);
  
  if (!verificacao.pode) {
    log('WARN', 'RATE', `Mensagem bloqueada: ${verificacao.motivo}`);
    return false;
  }
  
  try {
    const chat = await msg.getChat();
    
    // 1. Saudação inicial
    const saudacao = getSaudacao();
    const tempoSaudacao = 1 + Math.random();
    
    await chat.sendStateTyping();
    await new Promise(resolve => setTimeout(resolve, tempoSaudacao * 1000));
    await msg.reply(saudacao);
    await chat.clearState();
    registrarEnvio(from);
    
    // 2. Pausa natural (1-2s)
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));
    
    // 3. Introdução para o preço
    const intro = getSaudacaoPreco();
    const tempoIntro = 1 + Math.random() * 0.5;
    
    await chat.sendStateTyping();
    await new Promise(resolve => setTimeout(resolve, tempoIntro * 1000));
    await msg.reply(intro);
    await chat.clearState();
    registrarEnvio(from);
    
    // 4. Pausa natural (1-2s)
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));
    
    // 5. Resposta com preços
    const tempoPreco = Math.min(Math.max(texto.length / 50, 2), 5);
    
    await chat.sendStateTyping();
    await new Promise(resolve => setTimeout(resolve, tempoPreco * 1000));
    await msg.reply(texto);
    await chat.clearState();
    registrarEnvio(from);
    
    return true;
  } catch (e) {
    log('ERRO', 'WPP', 'Erro ao enviar: ' + e.message);
    return false;
  }
}

async function processarMensagem(msg, from, texto) {
  const t = normalizar(texto);
  
  // Verificar se é número de teste
  const ehTeste = ehNumeroTeste(from);
  if (ehTeste) {
    log('INFO', 'TESTE', `Mensagem de número de teste: ${from.substring(0, 20)}...`);
  }
  
  // =====================================
  // VERIFICAR SE ESTÁ AGUARDANDO ESCOLHA DE MARCA
  // =====================================
  if (clientesAguardandoMarca.has(from)) {
    const estado = clientesAguardandoMarca.get(from);
    const marcas = estado.marcasEncontradas;
    
    // Verificar se digitou número ou nome da marca
    let marcaEscolhida = null;
    
    // Se digitou número
    if (/^\d+$/.test(t)) {
      const idx = parseInt(t) - 1;
      if (idx >= 0 && idx < marcas.length) {
        marcaEscolhida = marcas[idx];
      }
    } else {
      // Se digitou nome da marca
      marcaEscolhida = MARCA_ALIASES[t] || t;
      if (!marcas.includes(marcaEscolhida)) {
        marcaEscolhida = null;
      }
    }
    
    if (marcaEscolhida) {
      clientesAguardandoMarca.delete(from);
      
      // Retornar produtos da marca escolhida
      const produtos = estado.porMarca[marcaEscolhida] || [];
      
      if (produtos.length > 0) {
        let resposta = `${marcaEscolhida.toUpperCase()} - ${produtos.length} produto(s):\n\n`;
        produtos.forEach(tela => {
          resposta += formatarRespostaTela(tela) + '\n';
        });
        
        if (!botAtivo) {
          resposta += '\n⚠️ No momento não temos atendentes disponíveis.';
        }
        
        await enviarRespostaPreco(msg, from, resposta, true);
        log('INFO', 'BUSCA', `Cliente escolheu marca: ${marcaEscolhida}`);
      } else {
        await enviarMensagemSegura(msg, from, 'Nenhum produto encontrado para essa marca.');
      }
      return;
    } else {
      // Resposta inválida
      await enviarMensagemSegura(msg, from, 'Opção inválida. Digite o número ou nome da marca.');
      return;
    }
  }
  
  // Verificar se está pausado (atendente)
  if (clientesPausados.has(from)) {
    if (t === 'bot') {
      clientesPausados.delete(from);
      await enviarMensagemSegura(msg, from,'🤖 Bot reativado!');
      return;
    }
    return;
  }
  
  // =====================================
  // BOT DESATIVADO (OFFLINE) - AVISA QUE NÃO TEM ATENDENTE
  // =====================================
  if (!botAtivo) {
    // Funciona igual ao bot ativo, mas avisa no final que não tem atendente
    // Números de teste IGNORAM verificação de horário
    
    // 1 - Atendente (mas não tem ninguém)
    if (t === '1' || t.includes('atendente') || t.includes('humano')) {
      await enviarMensagemSegura(msg, from,'⚠️ No momento não temos atendentes disponíveis.\n\nTodos estão ocupados assim que alguém ficar livre irá atendê-lo.\n\nObrigado pela compreensão!');
      return;
    }
    
    // 2 - Acessórios
    if (t === '2' || t.includes('acessorio')) {
      await enviarMensagemSegura(msg, from,'📱 Acessórios para celular\n\n⚠️ No momento não temos atendentes disponíveis para fechar seu pedido.\n\nTodos estão ocupados, aguarde que alguém irá atendê-lo.');
      return;
    }
    
    // 3 - Serviços
    if (t === '3' || t.includes('servico') || t.includes('orcamento')) {
      await enviarMensagemSegura(msg, from,'🔧 Serviços e orçamentos\n\n⚠️ No momento não temos técnicos disponíveis.\n\nTodos estão ocupados, aguarde que alguém irá atendê-lo.');
      return;
    }
    
    // 4 - Outros
    if (t === '4' || t === 'outros') {
      await enviarMensagemSegura(msg, from,'⚠️ No momento não temos atendentes disponíveis.\n\nTodos estão ocupados, aguarde que alguém irá atendê-lo.');
      return;
    }
    
    // 5 - Finalizar
    if (t === '5' || t.includes('finalizar') || t.includes('obrigado')) {
      await enviarMensagemSegura(msg, from,'👋 Obrigado pelo contato!');
      return;
    }
    
    // 6 ou 7 - Telas
    if (t === '6' || t === '7') {
      await enviarMensagemSegura(msg, from,'Me diga o modelo:');
      return;
    }
    
    // Buscar no banco
    const resultadoOffline = buscarNoBanco(texto);
    const { disponiveis, indisponiveis, porMarca, marcasEncontradas, palavrasBuscadas } = resultadoOffline;
    
    if (disponiveis.length > 0 || indisponiveis.length > 0) {
      // Se encontrou em MAIS DE UMA MARCA, perguntar
      if (marcasEncontradas.length > 1) {
        // Salvar estado e perguntar marca
        clientesAguardandoMarca.set(from, {
          porMarca: porMarca,
          marcasEncontradas: marcasEncontradas,
          termo: texto
        });
        
        let msgMarcas = `🔍 Encontrei "${palavrasBuscadas.join(' ')}" em ${marcasEncontradas.length} marcas:\n\n`;
        marcasEncontradas.forEach((marca, idx) => {
          const qtd = porMarca[marca].length;
          msgMarcas += `${idx + 1} - ${marca.toUpperCase()} (${qtd})\n`;
        });
        msgMarcas += '\nDigite o número da marca do seu aparelho:';
        
        await enviarMensagemSegura(msg, from,msgMarcas);
        return;
      }
      
      // Encontrou em 1 marca só - retorna direto
      if (disponiveis.length > 0) {
        let resposta = '';
        disponiveis.forEach(tela => {
          resposta += formatarRespostaTela(tela) + '\n';
        });
        resposta += '\n⚠️ No momento não temos atendentes disponíveis para fechar seu pedido.\n\nAssim que alguém ficar livre, irá atendê-lo.';
        await enviarRespostaPreco(msg, from, resposta, true);
        return;
      }
      
      if (indisponiveis.length > 0) {
        await enviarMensagemSegura(msg, from,'Esse modelo não está disponível no momento.\n\n⚠️ No momento não temos atendentes disponíveis.\n\nTodos estão ocupados, aguarde que alguém irá atendê-lo.');
        return;
      }
    }
    
    // Se mencionou tela/preço mas não encontrou
    if (t.includes('tela') || t.includes('preco') || t.includes('preço') || t.includes('valor')) {
      await enviarMensagemSegura(msg, from,'Não encontramos esse modelo.\n\n⚠️ No momento não temos atendentes disponíveis.\n\nTodos estão ocupados, aguarde que alguém irá atendê-lo.');
      return;
    }
    
    // Menu
    if (['oi', 'ola', 'olá', 'menu', 'inicio', 'start'].some(p => t.includes(p))) {
      await enviarMensagemSegura(msg, from,getMenuOffline());
      return;
    }
    
    // Resposta padrão
    await enviarMensagemSegura(msg, from,getMenuOffline());
    return;
  }
  
  // =====================================
  // BOT ATIVADO (ONLINE) - NORMAL
  // =====================================
  
  // 1 - Atendente
  if (t === '1' || t.includes('atendente') || t.includes('humano')) {
    clientesPausados.add(from);
    await enviarMensagemSegura(msg, from,'✅ Transferindo para atendente!\n\nAguarde um momento.\n\n_Para voltar ao bot, digite "bot"._');
    return;
  }
  
  // 2 - Acessórios
  if (t === '2' || t.includes('acessorio')) {
    await enviarMensagemSegura(msg, from,'📱 Acessórios para celular\n\nDigite 1 para falar com atendente.');
    return;
  }
  
  // 3 - Serviços
  if (t === '3' || t.includes('servico') || t.includes('orcamento')) {
    await enviarMensagemSegura(msg, from,'🔧 Serviços e orçamentos\n\nPara orçamentos, digite 1 para falar com técnico.');
    return;
  }
  
  // 4 - Outros
  if (t === '4' || t === 'outros') {
    await enviarMensagemSegura(msg, from,'Digite 1 para falar com atendente.');
    return;
  }
  
  // 5 - Finalizar
  if (t === '5' || t.includes('finalizar') || t.includes('obrigado')) {
    await enviarMensagemSegura(msg, from,'👋 Obrigado pelo contato!');
    return;
  }
  
  // 6 ou 7 - Telas
  if (t === '6' || t === '7') {
    // Números de teste ignoram verificação de horário
    if (!ehTeste && !horarioAtendimento()) {
      await enviarMensagemSegura(msg, from,getMensagemForaHorario());
      return;
    }
    await enviarMensagemSegura(msg, from,'Me diga o modelo:');
    return;
  }
  
  // =====================================
  // BUSCAR NO BANCO DE DADOS
  // =====================================
  const resultado = buscarNoBanco(texto);
  const { disponiveis, indisponiveis, porMarca, marcasEncontradas, palavrasBuscadas } = resultado;
  
  if (disponiveis.length > 0 || indisponiveis.length > 0) {
    // Números de teste ignoram verificação de horário
    if (!ehTeste && !horarioAtendimento()) {
      await enviarMensagemSegura(msg, from,getMensagemForaHorario());
      return;
    }
    
    estatisticas.consultasHoje++;
    
    // Se encontrou em MAIS DE UMA MARCA, perguntar
    if (marcasEncontradas.length > 1) {
      // Salvar estado e perguntar marca
      clientesAguardandoMarca.set(from, {
        porMarca: porMarca,
        marcasEncontradas: marcasEncontradas,
        termo: texto
      });
      
      let msgMarcas = `🔍 Encontrei "${palavrasBuscadas.join(' ')}" em ${marcasEncontradas.length} marcas:\n\n`;
      marcasEncontradas.forEach((marca, idx) => {
        const qtd = porMarca[marca].length;
        msgMarcas += `${idx + 1} - ${marca.toUpperCase()} (${qtd})\n`;
      });
      msgMarcas += '\nDigite o número da marca do seu aparelho:';
      
      await enviarMensagemSegura(msg, from,msgMarcas);
      log('INFO', 'BUSCA', `Perguntando marca: ${marcasEncontradas.join(', ')}${ehTeste ? ' [TESTE]' : ''}`);
      return;
    }
    
    // Encontrou em 1 marca só - retorna direto
    if (disponiveis.length > 0) {
      let resposta = '';
      disponiveis.forEach(tela => {
        resposta += formatarRespostaTela(tela) + '\n';
      });
      await enviarRespostaPreco(msg, from, resposta, true);
      log('INFO', 'BUSCA', `Encontrado: ${disponiveis.length} telas${ehTeste ? ' [TESTE]' : ''}`);
      return;
    }
    
    if (indisponiveis.length > 0) {
      await enviarMensagemSegura(msg, from,'Esse modelo não está disponível no momento em estoque.\n\nDigite 1 para falar com atendente.');
      return;
    }
  }
  
  // Se mencionou tela/preço mas não encontrou no banco
  if (t.includes('tela') || t.includes('preco') || t.includes('preço') || t.includes('valor')) {
    // Números de teste ignoram verificação de horário
    if (!ehTeste && !horarioAtendimento()) {
      await enviarMensagemSegura(msg, from,getMensagemForaHorario());
      return;
    }
    await enviarMensagemSegura(msg, from,'Não encontramos esse modelo no sistema.\n\nVerifique se digitou corretamente ou digite 1 para falar com atendente.');
    return;
  }
  
  // Menu
  if (['oi', 'ola', 'olá', 'menu', 'inicio', 'start'].some(p => t.includes(p))) {
    await enviarMensagemSegura(msg, from, getMenu(), true);
    return;
  }
  
  // Resposta padrão - menu
  await enviarMensagemSegura(msg, from, getMenu(), true);
}

function getMenu() {
  const emp = dadosTelas.empresa?.nome || "SUA LOJA";
  const msgBoasVindas = dadosTelas.empresa?.mensagemBoasVindas || "";
  
  let mensagem = `Olá! Seja bem-vindo(a) à ${emp} 📱`;
  if (msgBoasVindas) mensagem += `\n\n${msgBoasVindas}`;
  
  return mensagem + `\n\nSe for referente a TELAS, especifique o modelo:\nEx: Samsung A20S, Moto G05, Moto G30, iPhone 13\n\nSE NÃO digite uma opção:\n\n1 - Atendente\n2 - Acessórios para celular\n3 - Serviços e orçamentos\n4 - Outros\n5 - Finalizar\n6 - Telas\n7 - Preços de telas`;
}

function getMenuOffline() {
  const emp = dadosTelas.empresa?.nome || "SUA LOJA";
  const msgBoasVindas = dadosTelas.empresa?.mensagemBoasVindas || "";
  
  let mensagem = `Olá! Seja bem-vindo(a) à ${emp} 📱`;
  if (msgBoasVindas) mensagem += `\n\n${msgBoasVindas}`;
  
  return mensagem + `\n\nSe for referente a TELAS, especifique o modelo:\nEx: Samsung A20S, Moto G05, Moto G30, iPhone 13\n\n⚠️ No momento não temos atendentes disponíveis para fechar pedidos.\nTodos estão ocupados, assim que alguém ficar livre irá atendê-lo.\n\nSE NÃO digite uma opção:\n\n1 - Atendente\n2 - Acessórios para celular\n3 - Serviços e orçamentos\n4 - Outros\n5 - Finalizar\n6 - Telas\n7 - Preços de telas`;
}

// =====================================
// SOCKET.IO
// =====================================
io.on("connection", (socket) => {
  socket.emit("status", { conectado: whatsappConectado, mensagem: whatsappConectado ? "Conectado!" : "Aguardando..." });
  socket.emit("bot_status", botAtivo);
  socket.emit("modo_teste_status", { modoTeste, numerosTeste });
  
  if (!whatsappConectado) {
    socket.emit("qr", "loading");
  }
  
  socket.emit("dados_atualizados", { ...dadosTelas, botAtivo, modoTeste, numerosTeste });
  
  socket.emit("stats", {
    total: dadosTelas.telas?.length || 0,
    ativos: dadosTelas.telas?.filter(t => t.ativo).length || 0
  });
});

// =====================================
// INICIAR
// =====================================
server.listen(PORT, () => {
  const licenseMsg = licenseStatus === LICENSE_STATUS.VALID 
    ? '✅ Licenciado' 
    : licenseStatus === LICENSE_STATUS.TRIAL 
      ? `⏳ Trial (${licenseInfo.daysRemaining} dias)` 
      : '⚠️ NÃO LICENCIADO';
  
  console.log(`
╔══════════════════════════════════════════════════════════╗
║                                                          ║
║   📱 OSFY - SISTEMA DE PREÇOS                            ║
║   🚀 Inteligente e Resposta Rápida                       ║
║                                                          ║
║   🌐 Painel: http://localhost:${PORT}                      ║
║   🔐 Status: ${licenseMsg.padEnd(42)}║
║   🤖 Bot: ${botAtivo ? '🟢 Online' : '🔴 Offline'}                                        ║
║   🧪 Teste: ${modoTeste ? '🟢 Ativo (' + numerosTeste.length + ' núm.)' : '🔴 Inativo'}                               ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝
  `);
  
  // Bloqueia se não tiver licença válida ou trial
  if (licenseStatus !== LICENSE_STATUS.VALID && licenseStatus !== LICENSE_STATUS.TRIAL) {
    log('WARN', 'LICENÇA', 'Sistema BLOQUEADO - Aguardando ativação');
    log('INFO', 'LICENÇA', 'Acesse http://localhost:' + PORT + ' para ativar');
    return; // Não inicializa o bot
  }
  
  log('INFO', 'SISTEMA', 'Sistema iniciado - Bot ' + (botAtivo ? 'ONLINE' : 'OFFLINE') + ' | Teste: ' + (modoTeste ? 'ON' : 'OFF'));
  initWhatsApp();
});
