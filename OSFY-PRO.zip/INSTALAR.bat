@echo off
chcp 65001 >nul
title OSFY - Instalacao
color 0B
cls

echo.
echo  ========================================================
echo.
echo            OSFY - INSTALACAO
echo.
echo  ========================================================
echo.

cd /d "%~dp0"

:: Verifica se Node.js esta instalado
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo  ERRO: Node.js nao esta instalado!
    echo.
    echo  Baixe em: https://nodejs.org
    echo  Escolha a versao LTS.
    echo.
    pause
    exit /b 1
)

echo  Node.js encontrado!
echo.

:: Instala dependencias
echo  Instalando dependencias...
echo  Isso pode levar alguns minutos...
echo.

call npm install

echo.
echo  ========================================================
echo.
echo  INSTALACAO CONCLUIDA!
echo.
echo  Proximo passo: Execute INICIAR.bat
echo.
echo  ========================================================
echo.
pause
