; ============================================
; OSFY BASICO - Script do Instalador
; ============================================

#define MyAppName "OSFY"
#define MyAppVersion "2.5"
#define MyAppPlan "BASICO"
#define MyAppExeName "OSFY-BASICO.exe"

[Setup]
AppId={{OSFY-BASICO-2024-001}
AppName={#MyAppName} {#MyAppPlan}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion} - {#MyAppPlan}
DefaultDirName={autopf}\OSFY-Basico
DefaultGroupName=OSFY
AllowNoIcons=yes
OutputDir=dist
OutputBaseFilename=OSFY-BASICO-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\{#MyAppExeName}

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
Source: "dist\OSFY-BASICO\OSFY-BASICO.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-BASICO\public\*"; DestDir: "{app}\public"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "dist\OSFY-BASICO\license-system\*"; DestDir: "{app}\license-system"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "dist\OSFY-BASICO\telas.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-BASICO\config.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-BASICO\base-conhecimento.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-BASICO\planos-config.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-BASICO\plano.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\OSFY Basico"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\OSFY Basico"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,OSFY}"; Flags: nowait postinstall skipifsilent

[Code]
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
    CreateDir(ExpandConstant('{app}\backups'));
end;
