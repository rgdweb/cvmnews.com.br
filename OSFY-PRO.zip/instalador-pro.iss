; ============================================
; OSFY PRO - Script do Instalador
; ============================================

#define MyAppName "OSFY"
#define MyAppVersion "2.5"
#define MyAppPlan "PRO"
#define MyAppExeName "OSFY-PRO.exe"

[Setup]
AppId={{OSFY-PRO-2024-001}
AppName={#MyAppName} {#MyAppPlan}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion} - {#MyAppPlan}
DefaultDirName={autopf}\OSFY-Pro
DefaultGroupName=OSFY
AllowNoIcons=yes
OutputDir=dist
OutputBaseFilename=OSFY-PRO-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\{#MyAppExeName}

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
Source: "dist\OSFY-PRO\OSFY-PRO.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-PRO\public\*"; DestDir: "{app}\public"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "dist\OSFY-PRO\license-system\*"; DestDir: "{app}\license-system"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "dist\OSFY-PRO\telas.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-PRO\config.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-PRO\base-conhecimento.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-PRO\planos-config.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-PRO\plano.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\OSFY Pro"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\OSFY Pro"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,OSFY}"; Flags: nowait postinstall skipifsilent

[Code]
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
    CreateDir(ExpandConstant('{app}\backups'));
end;
