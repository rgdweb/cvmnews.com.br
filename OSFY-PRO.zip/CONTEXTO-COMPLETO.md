# CONTEXTO COMPLETO - SISTEMA OSFY

> Este documento contem TODAS as informacoes sobre o sistema OSFY. Leia completamente antes de qualquer alteracao ou conversa com o desenvolvedor.

---

## IDENTIFICACAO DO PROJETO

**Nome:** OSFY - Sistema de Precos Inteligente
**Versao:** 1.0
**Tipo:** Bot WhatsApp para consulta automatica de precos
**Publico-alvo:** Lojas de celulares, assistencias tecnicas, lojas de pecas

---

## O QUE O SISTEMA FAZ

### Funcionalidade Principal
O sistema responde automaticamente consultas de preco via WhatsApp. O cliente manda "quanto custa tela do moto g05" e o bot retorna o preco instantaneamente, 24/7.

### Fluxo de Funcionamento
```
1. Cliente envia mensagem no WhatsApp da loja
2. Bot recebe e processa a mensagem
3. Bot busca no banco de dados (telas.json)
4. Bot retorna os precos encontrados
5. Se nao encontrar, oferece menu de opcoes
```

### Menu do Bot
- Opcao 1: Falar com atendente (pausa bot)
- Opcao 2: Acessorios
- Opcao 3: Servicos/Orcamentos
- Opcao 4: Outros
- Opcao 5: Finalizar
- Opcoes 6/7: Consultar telas

---

## ESTRUTURA DE ARQUIVOS

```
copias-do-osfy/
├── server.js                 # SERVIDOR PRINCIPAL - Toda a logica
├── telas.json                # BANCO DE DADOS - Produtos e precos
├── config.json               # Configuracoes basicas
├── package.json              # Dependencias Node.js
├── license.enc               # Licenca criptografada (gerado apos ativacao)
├── .trial                    # Arquivo de trial (gerado automaticamente)
│
├── license-system/           # SISTEMA DE LICENCIAMENTO
│   ├── license-validator.js  # Valida licenca e trial
│   ├── license-generator.js  # Gera novas licencas (vendedor)
│   ├── hardware-id.js        # Identificacao unica do PC
│   └── encrypt.js            # Criptografia AES-256
│
├── public/                   # INTERFACE WEB
│   ├── index.html            # Painel administrativo
│   └── activate.html         # Pagina de ativacao
│
├── backups/                  # Backups automaticos
├── node_modules/             # Dependencias
│   └── .osfy-registry        # REGISTRO OCULTO DO TRIAL
│
├── INICIAR.bat               # Iniciar o sistema
├── INSTALAR.bat              # Instalar dependencias
├── GERADOR-LICENCA.bat       # Atalho para gerador
├── CRIAR-ZIP-VENDA.bat       # Criar ZIP para venda
├── COMPILAR-EXE.bat          # Compilar executavel
└── CONFIGURAR.bat            # Configurar dados da empresa
```

---

## SISTEMA DE LICENCA

### Como Funciona
1. **Trial de 7 dias** - Cliente testa gratis
2. **Apos trial** - Sistema bloqueia, pede ativacao
3. **Ativacao** - Cliente recebe SERIAL do vendedor
4. **Licenca vitalicia** - 1 ano (365 dias) por padrao

### NOVO: Licenca com CPF (Intransferivel)
- V2.0 do sistema de licenca
- Cada licenca e vinculada ao CPF do cliente
- CPF e validado (algoritmo oficial brasileiro)
- Mesmo se copiar arquivos, nao funciona (CPF nao bate)
- Protecao extra contra pirataria

### Protecao Anti-Burla do Trial
O trial é registrado em **3 locais**:
1. `.trial` (arquivo visivel)
2. `node_modules/.osfy-registry` (arquivo oculto)
3. Registro do Windows (HKCU\Software\OSFY)

Se o cliente deletar o `.trial`, o sistema detecta e continua de onde parou.

### Identificacao Unica
Cada PC tem um **requestCode** unico gerado por:
- MAC Address
- Serial do disco rigido
- UUID da placa mae
- Hostname

Formato: `OSFY-XXXX-XXXX-XXXX`

### Arquivos Importantes
- `license-validator.js` - Valida se licenca é valida
- `license-generator.js` - Gera serial (uso do vendedor)
- `license.enc` - Licenca criptografada

---

## PAINEL ADMINISTRATIVO

### Acesso
URL: http://localhost:3000
Se licença invalida → Redireciona para activate.html

### Funcionalidades do Painel
1. **Dashboard** - Total de produtos, ativos, consultas
2. **Status WhatsApp** - Conectado/Desconectado + QR Code
3. **Toggle Bot** - Online/Offline
4. **Modo Teste** - Testar com numeros especificos
5. **Dados da Empresa** - Nome, telefone, cidade, horario
6. **Gerenciar Produtos** - CRUD completo

### API Endpoints (server.js)

| Metodo | Rota | Funcao |
|--------|------|--------|
| GET | /api/empresa | Dados da empresa |
| POST | /api/empresa | Atualizar dados |
| GET | /api/telas | Listar produtos |
| POST | /api/telas | Adicionar produto |
| PUT | /api/telas/:id | Editar produto |
| DELETE | /api/telas/:id | Remover produto |
| POST | /api/telas/:id/toggle | Ativar/desativar |
| GET | /api/stats | Estatisticas |
| GET | /api/license | Status da licenca |
| POST | /api/license/activate | Ativar com serial |
| POST | /api/bot/toggle | Liga/desliga bot |

---

## WHATSAPP BOT

### Tecnologia
- **whatsapp-web.js** - Biblioteca nao oficial
- **LocalAuth** - Sessao persistente (escaneia uma vez)
- **puppeteer** - Automacao

### Sessao Persistente
A sessao fica salva em `.wwebjs_auth/`
Cliente so escaneia QR Code na primeira vez.

### Protecao Anti-Bloqueio
1. **Rate Limiting** - Max 5 msg/min por numero, 30/min global
2. **Delay entre mensagens** - 2 segundos
3. **Typing indicator** - Mostra "digitando..." antes de responder
4. **Saudacoes variadas** - Nao repete sempre igual

### Saudacoes Humanizadas
```javascript
// Manha (5h-12h)
['Bom dia!', 'Ola, bom dia!', 'Bom dia, tudo bem?', 'Oi, bom dia!']

// Tarde (12h-18h)
['Boa tarde!', 'Ola, boa tarde!', 'Boa tarde, tudo bem?', 'Oi, boa tarde!']

// Noite (18h-24h)
['Boa noite!', 'Ola, boa noite!', 'Boa noite, tudo bem?', 'Oi, boa noite!']
```

### Risco de Bloqueio
Como é biblioteca nao oficial, ha risco. As protecoes reduzem mas nao eliminam 100%.

---

## CONFIGURACOES DA EMPRESA

### Dados Configuraveis
- Nome da loja
- Telefone
- Cidade
- Mensagem de boas-vindas
- Horario de atendimento

### Horario de Atendimento
- Segunda a sexta: 2 turnos
- Sabado: 1 turno
- Domingo: fechado

### Mensagem Fora do Horario
Enviada automaticamente quando cliente manda mensagem fora do horario configurado.

---

## BANCO DE DADOS (telas.json)

### Estrutura de um Produto
```json
{
  "id": "1234567890",
  "marca": "motorola",
  "modelo": "MOTO G05 /G15 /G35",
  "tipo": "OLED COM ARO",
  "observacao": "Caixa Vermelha",
  "preco": 150.00,
  "estoque": 5,
  "ativo": true
}
```

### Marcas Suportadas
alcatel, apple, asus, huawei, honor, iphone, lenovo, lg, motorola, moto, multilaser, nokia, oneplus, oppo, poco, positivo, realme, redmi, samsung, tcl, vivo, xiaomi, zenfone, zte

---

## INSTRUCOES DE INSTALACAO

### Requisitos
- Windows 10 ou superior
- Node.js 18+
- Conexao internet

### Passos
1. Extrair ZIP
2. Clicar em `INSTALAR.bat`
3. Aguardar instalar dependencias
4. Clicar em `INICIAR.bat`
5. Acessar http://localhost:3000
6. Escanear QR Code do WhatsApp

---

## INSTRUCOES PARA O VENDEDOR

### Gerar Licenca para Cliente (NOVO - Com CPF)
1. Cliente envia `requestCode` (codigo OSFY-XXXX-XXXX-XXXX)
2. Vendedor pede o CPF do cliente
3. Vendedor executa `GERADOR-LICENCA.bat`
4. Informa:
   - Request code do cliente
   - Nome do cliente
   - CPF do cliente (validado automaticamente)
   - Dias de validade (padrao 365)
5. Sistema gera SERIAL vinculado ao CPF
6. Vendedor envia SERIAL ao cliente
7. Cliente cola no painel e ativa

### ATENCAO: Licenca Intransferivel
- A licenca gerada so funciona no PC do cliente
- E vinculada ao CPF informado
- Nao pode ser transferida para outra pessoa
- Se o cliente quiser em outro PC, precisa de nova licenca

### Arquivo de Licenca
O gerador cria `licenses-database.json` com historico de todas as licencas geradas.

---

## GITHUB

**Repositorio:** https://github.com/rgdweb/copias-do-osfy
**ZIP:** https://github.com/rgdweb/copias-do-osfy/raw/main/OSFY-COMPLETO.zip

> Token de acesso deve ser solicitado ao desenvolvedor quando necessario.

---

## CONTATO DO DESENVOLVEDOR

**WhatsApp:** (49) 99841-8446
**Cidade:** Chapeco - SC

---

## ALTERACOES IMPORTANTES FEITAS

### Historico de Mudancas
1. Arquivos .bat sem emojis (encoding Windows)
2. "+Nova Tela" alterado para "+Itens"
3. Protecao anti-burla do trial (3 registros)
4. Rate limiting anti-bloqueio
5. Saudacoes humanizadas
6. Typing indicator ("digitando...")
7. NOVO: Sistema de licenca v2.0 com CPF (intransferivel)

### Arquivos que NAO devem ser alterados sem cuidado
- `server.js` - Toda a logica principal
- `license-validator.js` - Sistema de licenca
- `hardware-id.js` - Identificacao unica
- `encrypt.js` - Criptografia

---

## MELHORIAS PLANEJADAS

### Proxima Versao
1. Painel de licenca integrado (tudo pelo painel) - PARCIAL
2. Sistema de relatorios de vendas - PARCIAL
3. Fluxo de upgrade trial -> mensal
4. CPF na licenca (intransferivel) - IMPLEMENTADO

### Futuro
- Multi-idioma
- App mobile para vendedor
- Dashboard na nuvem

---

## REGRAS PARA FUTURAS ALTERACOES

1. **SEMPRE** testar apos alteracoes
2. **NAO** modificar logica de licenca sem backup
3. **NAO** adicionar emojis em arquivos .bat
4. **SEMPRE** manter compatibilidade com Windows
5. **SEMPRE** atualizar este documento apos mudancas

---

## TESTES A FAZER APOS ALTERACOES

1. Iniciar sistema (`INICIAR.bat`)
2. Verificar painel carrega (localhost:3000)
3. Verificar QR Code aparece
4. Testar conexao WhatsApp
5. Testar bot responde mensagens
6. Testar trial funciona (deletar license.enc)
7. Testar ativacao de licenca
8. Testar painel salva produtos
9. Testar horario de atendimento
10. Verificar logs no console

---

*Documento criado em: Abril 2025*
*Ultima atualizacao: 11/04/2025 - v2.0 com CPF*
*Mantenha este documento atualizado a cada mudanca significativa*
