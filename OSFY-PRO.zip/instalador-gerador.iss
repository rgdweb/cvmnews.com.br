; ============================================
; OSFY GERADOR DE LICENÇAS - Script do Instalador
; ============================================

#define MyAppName "OSFY Gerador de Licencas"
#define MyAppVersion "2.5"

[Setup]
AppId={{OSFY-GERADOR-2024-001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
DefaultDirName={autopf}\OSFY-Gerador
DefaultGroupName=OSFY
AllowNoIcons=yes
OutputDir=dist
OutputBaseFilename=GERADOR-LICENCAS-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\GERADOR-LICENCA.bat

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
; Arquivos do gerador
Source: "license-system\license-generator-planos.js"; DestDir: "{app}"; Flags: ignoreversion
Source: "license-system\encrypt.js"; DestDir: "{app}"; Flags: ignoreversion
Source: "license-system\hardware-id.js"; DestDir: "{app}"; Flags: ignoreversion
Source: "planos-config.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "package.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "package-lock.json"; DestDir: "{app}"; Flags: ignoreversion

; Script para rodar o gerador
Source: "GERADOR-LICENCA-PLANOS.bat"; DestDir: "{app}"; Flags: ignoreversion

; Documentacao
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "TABELA-PRECO-PLANOS.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "GUIA-VENDEDOR.md"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\OSFY Gerador de Licencas"; Filename: "{app}\GERADOR-LICENCA-PLANOS.bat"; WorkingDir: "{app}"
Name: "{autodesktop}\OSFY Gerador"; Filename: "{app}\GERADOR-LICENCA-PLANOS.bat"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\GERADOR-LICENCA-PLANOS.bat"; Description: "Abrir Gerador de Licencas"; Flags: postinstall shellexec skipifsilent; WorkingDir: "{app}"
