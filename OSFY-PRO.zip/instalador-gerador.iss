; ============================================
; OSFY GERADOR DE LICENÇAS - Script do Instalador
; ============================================

#define MyAppName "OSFY Gerador de Licencas"
#define MyAppVersion "2.5"
#define MyAppExeName "GERADOR-LICENCAS-OSFY.exe"

[Setup]
AppId={{OSFY-GERADOR-2024-001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
DefaultDirName={autopf}\OSFY-Gerador
DefaultGroupName=OSFY
AllowNoIcons=yes
OutputDir=dist
OutputBaseFilename=GERADOR-LICENCAS-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\{#MyAppExeName}

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
Source: "dist\GERADOR-LICENCAS\GERADOR-LICENCAS-OSFY.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\GERADOR-LICENCAS\planos-config.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\OSFY Gerador de Licencas"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\OSFY Gerador"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,OSFY Gerador}"; Flags: nowait postinstall skipifsilent
