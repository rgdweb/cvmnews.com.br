# 📱 OSFY - Guia do Vendedor

## 🔐 SEUS ARQUIVOS (NÃO ENVIAR PARA CLIENTES)

```
├── GERADOR-LICENCA.bat    ← Você clica para gerar licenças
├── license-system/
│   └── license-generator.js
└── licenses-database.json ← Banco de licenças geradas
```

---

## 📋 COMO FUNCIONA A VENDA

### PASSO 1: Cliente instala o sistema
- Cliente baixa o ZIP do sistema (sem o gerador)
- Executa `INSTALAR.bat`
- Executa `INICIAR.bat`
- Sistema mostra **Código de Solicitação**: `OSFY-XXXX-XXXX-XXXX`

### PASSO 2: Cliente te envia o código
- Cliente manda o código por WhatsApp: **(49) 99841-8446**

### PASSO 3: Você gera a licença
1. Clica em `GERADOR-LICENCA.bat`
2. Digita `1` para nova licença
3. Cole o código do cliente
4. Digita o nome do cliente
5. Digite os dias (padrão: 365 = 1 ano)
6. Recebe a **CHAVE DE ATIVAÇÃO**

### PASSO 4: Você envia a chave
- Manda a chave para o cliente
- Cliente digita no sistema
- Sistema liberado! ✅

---

## 🛠️ PREPARAR PARA VENDA

### 1. Criar ZIP para o cliente
```bash
# NÃO incluir estes arquivos:
- GERADOR-LICENCA.bat
- license-system/license-generator.js
- licenses-database.json
- .git/
- node_modules/
```

### 2. Criar executável .EXE (opcional)
```bash
# Instalar pkg
npm install -g pkg

# Compilar
pkg server.js --targets node18-win-x64 --output osfy.exe
```

---

## 💰 MODELOS DE LICENÇA

| Plano | Dias | Valor Sugerido |
|-------|------|----------------|
| Mensal | 30 | R$ 49,90 |
| Trimestral | 90 | R$ 129,90 |
| Anual | 365 | R$ 299,90 |
| Vitalício | 36500 | R$ 499,90 |

---

## 🔒 SEGURANÇA

- Cada licença é única para cada computador
- Se o cliente formatar, precisa de nova licença
- Se tentar usar em outro PC, bloqueia automaticamente
- Trial de 7 dias antes de exigir licença

---

## 📞 SEU CONTATO PARA SUPORTE

WhatsApp: (49) 99841-8446

---

## ⚠️ IMPORTANTE

**NUNCA enviar para o cliente:**
- `GERADOR-LICENCA.bat`
- `license-system/license-generator.js`
- `licenses-database.json`

**Isso é o seu controle! Se o cliente tiver esses arquivos, ele pode gerar licenças!**
