@echo off
chcp 65001 >nul
title OSFY - Configuracao Inicial
color 0A
cls

echo.
echo  ========================================================
echo.
echo            OSFY - CONFIGURACAO INICIAL
echo           Configure os dados da sua empresa
echo.
echo  ========================================================
echo.

echo  Este assistente vai configurar os dados da sua empresa.
echo  Essas informacoes aparecerao nas mensagens do bot.
echo.
echo  --------------------------------------------------------
echo.

set /p NOME="Nome da Loja: "
set /p TELEFONE="Telefone (ex: 49999999999): "
set /p CIDADE="Cidade (ex: Chapeco - SC): "

echo.
echo  --------------------------------------------------------
echo.

echo  Horario de Atendimento
echo.
set /p HORARIO1="Manha (ex: 09:00-12:00): "
set /p HORARIO2="Tarde (ex: 13:30-18:30): "
set /p HORARIOSAB="Sabado (ex: 09:00-13:00): "

:: Criar arquivo de configuracao
echo {> empresa-config.json
echo   "nome": "%NOME%",>> empresa-config.json
echo   "telefone": "%TELEFONE%",>> empresa-config.json
echo   "cidade": "%CIDADE%",>> empresa-config.json
echo   "horarioTexto": "Seg-Sex: %HORARIO1% e %HORARIO2% ^| Sab: %HORARIOSAB%">> empresa-config.json
echo }>> empresa-config.json

echo.
echo  --------------------------------------------------------
echo.
echo  Configuracao salva no arquivo empresa-config.json
echo.
echo  Para completar a configuracao:
echo     1. Execute INICIAR.bat
echo     2. Acesse http://localhost:3000
echo     3. Configure o nome da empresa no painel
echo.
echo  --------------------------------------------------------
echo.
pause
