@echo off
chcp 65001 >nul
title OSFY - Gerador de Licencas com Planos
color 0A
cls

echo.
echo  ========================================================
echo.
echo            OSFY - GERADOR DE LICENCAS
echo           (Sistema com Planos)
echo.
echo  ========================================================
echo.

cd /d "%~dp0"

:: Verifica se Node.js esta instalado
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo  ERRO: Node.js nao esta instalado!
    echo  Baixe em: https://nodejs.org
    echo.
    pause
    exit /b 1
)

echo  Node.js encontrado!
echo.

node license-system/license-generator-planos.js

pause
