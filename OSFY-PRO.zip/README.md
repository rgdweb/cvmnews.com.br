# OSFY - Sistema de Preços via WhatsApp

Bot inteligente para consulta de preços pelo WhatsApp com sistema de licenças.

---

## 💰 Planos e Preços

| Plano | Mensal | Anual | Vitalício |
|-------|--------|-------|-----------|
| **BÁSICO** | R$ 49/mês | R$ 397 | - |
| **PRO** | R$ 89/mês | R$ 697 | - |
| **PREMIUM** | R$ 149/mês | R$ 997 | R$ 2.997 |

### O que cada plano inclui:

| Recurso | Básico | Pro | Premium |
|---------|--------|-----|---------|
| Produtos | 100 | ∞ | ∞ |
| Consulta WhatsApp | ✅ | ✅ | ✅ |
| Relatórios | ❌ | ✅ | ✅ |
| Backup Automático | ❌ | ❌ | ✅ |
| Multi-empresa | ❌ | ❌ | ✅ |
| Suporte | Email | WhatsApp | Prioritário |

---

## 🎯 Trial Grátis

- 7 dias grátis para testar
- Até 20 produtos
- Sem cartão de crédito

---

## 📋 Como Funciona

### Para o Vendedor:

1. Execute `CRIAR-INSTALADOR-TUDO.bat` opção 5
2. Instale o `GERADOR-LICENCAS-Setup.exe` no seu PC
3. Quando um cliente comprar, gere a licença com CPF dele
4. Envie o instalador do plano + a chave de ativação

### Para o Cliente:

1. Instala o programa
2. Abre e vê um código de solicitação
3. Te envia o código + CPF
4. Você gera a chave de ativação
5. Cliente ativa e usa!

---

## 📁 Arquivos Importantes

| Arquivo | Para quem |
|---------|-----------|
| `CRIAR-INSTALADOR-TUDO.bat` | Vendedor |
| `GERADOR-LICENCA-PLANOS.bat` | Vendedor |
| `OSFY-BASICO-Setup.exe` | Cliente |
| `OSFY-PRO-Setup.exe` | Cliente |
| `OSFY-PREMIUM-Setup.exe` | Cliente |

---

## ⚠️ Importante

- **NUNCA** envie o GERADOR DE LICENÇAS para o cliente
- A licença é vinculada ao CPF (intransferível)
- Você pode revogar licenças de clientes inadimplentes

---

## 📞 Suporte

Duvidas? Entre em contato pelo WhatsApp.

---

© 2024 OSFY
