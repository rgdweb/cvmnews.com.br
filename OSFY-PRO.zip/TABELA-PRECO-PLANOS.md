# OSFY - Tabela de Preços

## Planos Disponíveis

### BÁSICO - R$ 79/mês ou R$ 697/ano

**Para quem:** Pequenos comerciantes começando com automação

| Recurso | Incluído |
|---------|----------|
| Produtos | Até 100 |
| Consulta WhatsApp | ✅ |
| Trial grátis | 7 dias |
| Suporte | Email |

**Cálculo:** Anual = R$ 58/mês (economia de R$ 251)

---

### PRO - R$ 149/mês ou R$ 1.297/ano

**Para quem:** Negócios em crescimento que precisam de mais

| Recurso | Incluído |
|---------|----------|
| Produtos | Ilimitado |
| Consulta WhatsApp | ✅ |
| Relatórios | ✅ |
| Modo Teste | ✅ |
| Exportar CSV | ✅ |
| Trial grátis | 7 dias |
| Suporte | WhatsApp |

**Cálculo:** Anual = R$ 108/mês (economia de R$ 491)

---

### PREMIUM - R$ 247/mês ou R$ 1.997/ano ou R$ 2.497 vitalício

**Para quem:** Empresas estabelecidas que querem tudo

| Recurso | Incluído |
|---------|----------|
| Produtos | Ilimitado |
| Consulta WhatsApp | ✅ |
| Relatórios | ✅ |
| Modo Teste | ✅ |
| Exportar CSV | ✅ |
| Backup Automático | ✅ |
| **Multi-empresa** | ✅ **Ilimitado** |
| API Personalizada | ✅ |
| Trial grátis | 7 dias |
| Suporte | Prioritário |

**Vitalício:** Pague uma vez, use para sempre!
**Multi-empresa:** Gerencie várias lojas com uma única licença!

---

## Comparativo Rápido

| Recurso | Básico | Pro | Premium |
|---------|--------|-----|---------|
| Produtos | 100 | ∞ | ∞ |
| Relatórios | ❌ | ✅ | ✅ |
| Exportar CSV | ❌ | ✅ | ✅ |
| Backup Auto | ❌ | ❌ | ✅ |
| **Multi-empresa** | ❌ | ❌ | ✅ |
| Suporte | Email | WhatsApp | Prioritário |
| **Mensal** | R$ 79 | R$ 149 | R$ 247 |
| **Anual** | R$ 697 | R$ 1.297 | R$ 1.997 |
| **Vitalício** | - | - | R$ 2.497 |

---

## Destaque Premium

> 🏢 **Multi-empresa**: Com o plano Premium você pode gerenciar múltiplas lojas/empresas com uma única licença! Cada empresa tem seus próprios produtos e configurações independentes. Perfeito para quem tem mais de uma unidade!

---

## Dica de Venda

> "O cliente teste 7 dias grátis. Se gostar, escolhe o plano que cabe no bolso. O anual sempre sai mais barato!"

---

## Para o Vendedor

Ao gerar a licença, pergunte:
1. Qual plano o cliente escolheu?
2. É mensal, anual ou vitalício (só Premium)?
3. CPF do cliente

O sistema calcula automaticamente a data de expiração.
