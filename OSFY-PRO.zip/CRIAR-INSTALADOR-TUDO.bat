@echo off
chcp 65001 >nul
title OSFY - Criar Instaladores
color 0A

cd /d "%~dp0"

echo.
echo  ========================================================
echo.
echo            OSFY - CRIAR INSTALADORES
echo.
echo  ========================================================
echo.
echo  1 - BASICO    2 - PRO    3 - PREMIUM    4 - GERADOR    5 - TODOS
echo.
set /p opcao="Opcao: "

if not exist "dist" mkdir "dist"

where pkg >nul 2>nul
if %errorlevel% neq 0 (
    echo  Instalando pkg...
    npm install -g pkg
)

set ISCC="C:\Program Files\Inno Setup 7\ISCC.exe"
if not exist %ISCC% set ISCC="C:\Program Files (x86)\Inno Setup 7\ISCC.exe"

echo.
echo  ========================================================

if "%opcao%"=="5" (
    echo  Compilando BASICO...
    pkg server.js --targets node18-win-x64 --output "dist/OSFY-BASICO.exe" --config package.json
    if exist "dist\OSFY-BASICO.exe" (
        if exist "dist\OSFY-BASICO" rmdir /s /q "dist\OSFY-BASICO"
        mkdir "dist\OSFY-BASICO"
        move "dist\OSFY-BASICO.exe" "dist\OSFY-BASICO\" >nul
        xcopy /E /I /Q "public" "dist\OSFY-BASICO\public" >nul
        mkdir "dist\OSFY-BASICO\license-system" 2>nul
        copy "license-system\*.js" "dist\OSFY-BASICO\license-system\" >nul
        copy "telas.json" "dist\OSFY-BASICO\" >nul
        copy "config.json" "dist\OSFY-BASICO\" >nul
        copy "base-conhecimento.json" "dist\OSFY-BASICO\" >nul
        copy "planos-config.json" "dist\OSFY-BASICO\" >nul
        echo {"plano":"BASICO","maxProdutos":100} > "dist\OSFY-BASICO\plano.json"
        echo  BASICO.exe OK!
    ) else (
        echo  ERRO ao compilar BASICO!
    )
    echo.
    echo  Compilando PRO...
    pkg server.js --targets node18-win-x64 --output "dist/OSFY-PRO.exe" --config package.json
    if exist "dist\OSFY-PRO.exe" (
        if exist "dist\OSFY-PRO" rmdir /s /q "dist\OSFY-PRO"
        mkdir "dist\OSFY-PRO"
        move "dist\OSFY-PRO.exe" "dist\OSFY-PRO\" >nul
        xcopy /E /I /Q "public" "dist\OSFY-PRO\public" >nul
        mkdir "dist\OSFY-PRO\license-system" 2>nul
        copy "license-system\*.js" "dist\OSFY-PRO\license-system\" >nul
        copy "telas.json" "dist\OSFY-PRO\" >nul
        copy "config.json" "dist\OSFY-PRO\" >nul
        copy "base-conhecimento.json" "dist\OSFY-PRO\" >nul
        copy "planos-config.json" "dist\OSFY-PRO\" >nul
        echo {"plano":"PRO","maxProdutos":-1} > "dist\OSFY-PRO\plano.json"
        echo  PRO.exe OK!
    ) else (
        echo  ERRO ao compilar PRO!
    )
    echo.
    echo  Compilando PREMIUM...
    pkg server.js --targets node18-win-x64 --output "dist/OSFY-PREMIUM.exe" --config package.json
    if exist "dist\OSFY-PREMIUM.exe" (
        if exist "dist\OSFY-PREMIUM" rmdir /s /q "dist\OSFY-PREMIUM"
        mkdir "dist\OSFY-PREMIUM"
        move "dist\OSFY-PREMIUM.exe" "dist\OSFY-PREMIUM\" >nul
        xcopy /E /I /Q "public" "dist\OSFY-PREMIUM\public" >nul
        mkdir "dist\OSFY-PREMIUM\license-system" 2>nul
        copy "license-system\*.js" "dist\OSFY-PREMIUM\license-system\" >nul
        copy "telas.json" "dist\OSFY-PREMIUM\" >nul
        copy "config.json" "dist\OSFY-PREMIUM\" >nul
        copy "base-conhecimento.json" "dist\OSFY-PREMIUM\" >nul
        copy "planos-config.json" "dist\OSFY-PREMIUM\" >nul
        echo {"plano":"PREMIUM","maxProdutos":-1} > "dist\OSFY-PREMIUM\plano.json"
        echo  PREMIUM.exe OK!
    ) else (
        echo  ERRO ao compilar PREMIUM!
    )
    echo.
    echo  Compilando GERADOR...
    pkg license-system/license-generator-planos.js --targets node18-win-x64 --output "dist/GERADOR-LICENCAS-OSFY.exe"
    if exist "dist\GERADOR-LICENCAS-OSFY.exe" (
        if exist "dist\GERADOR-LICENCAS" rmdir /s /q "dist\GERADOR-LICENCAS"
        mkdir "dist\GERADOR-LICENCAS"
        move "dist\GERADOR-LICENCAS-OSFY.exe" "dist\GERADOR-LICENCAS\" >nul
        copy "planos-config.json" "dist\GERADOR-LICENCAS\" >nul
        echo  GERADOR.exe OK!
    ) else (
        echo  ERRO ao compilar GERADOR!
    )
    echo.
    echo  ========================================================
    echo  CRIANDO INSTALADORES...
    echo  ========================================================
    echo.
    echo  Instalador BASICO...
    %ISCC% "instalador-basico.iss"
    echo.
    echo  Instalador PRO...
    %ISCC% "instalador-pro.iss"
    echo.
    echo  Instalador PREMIUM...
    %ISCC% "instalador-premium.iss"
    echo.
    echo  Instalador GERADOR...
    %ISCC% "instalador-gerador.iss"
    goto MOSTRAR
)

if "%opcao%"=="1" (
    echo  Compilando BASICO...
    pkg server.js --targets node18-win-x64 --output "dist/OSFY-BASICO.exe" --config package.json
    if exist "dist\OSFY-BASICO.exe" (
        if exist "dist\OSFY-BASICO" rmdir /s /q "dist\OSFY-BASICO"
        mkdir "dist\OSFY-BASICO"
        move "dist\OSFY-BASICO.exe" "dist\OSFY-BASICO\" >nul
        xcopy /E /I /Q "public" "dist\OSFY-BASICO\public" >nul
        mkdir "dist\OSFY-BASICO\license-system" 2>nul
        copy "license-system\*.js" "dist\OSFY-BASICO\license-system\" >nul
        copy "telas.json" "dist\OSFY-BASICO\" >nul
        copy "config.json" "dist\OSFY-BASICO\" >nul
        copy "base-conhecimento.json" "dist\OSFY-BASICO\" >nul
        copy "planos-config.json" "dist\OSFY-BASICO\" >nul
        echo {"plano":"BASICO","maxProdutos":100} > "dist\OSFY-BASICO\plano.json"
        echo  BASICO.exe OK!
    )
    echo  Instalador...
    %ISCC% "instalador-basico.iss"
    goto MOSTRAR
)

if "%opcao%"=="2" (
    echo  Compilando PRO...
    pkg server.js --targets node18-win-x64 --output "dist/OSFY-PRO.exe" --config package.json
    if exist "dist\OSFY-PRO.exe" (
        if exist "dist\OSFY-PRO" rmdir /s /q "dist\OSFY-PRO"
        mkdir "dist\OSFY-PRO"
        move "dist\OSFY-PRO.exe" "dist\OSFY-PRO\" >nul
        xcopy /E /I /Q "public" "dist\OSFY-PRO\public" >nul
        mkdir "dist\OSFY-PRO\license-system" 2>nul
        copy "license-system\*.js" "dist\OSFY-PRO\license-system\" >nul
        copy "telas.json" "dist\OSFY-PRO\" >nul
        copy "config.json" "dist\OSFY-PRO\" >nul
        copy "base-conhecimento.json" "dist\OSFY-PRO\" >nul
        copy "planos-config.json" "dist\OSFY-PRO\" >nul
        echo {"plano":"PRO","maxProdutos":-1} > "dist\OSFY-PRO\plano.json"
        echo  PRO.exe OK!
    )
    echo  Instalador...
    %ISCC% "instalador-pro.iss"
    goto MOSTRAR
)

if "%opcao%"=="3" (
    echo  Compilando PREMIUM...
    pkg server.js --targets node18-win-x64 --output "dist/OSFY-PREMIUM.exe" --config package.json
    if exist "dist\OSFY-PREMIUM.exe" (
        if exist "dist\OSFY-PREMIUM" rmdir /s /q "dist\OSFY-PREMIUM"
        mkdir "dist\OSFY-PREMIUM"
        move "dist\OSFY-PREMIUM.exe" "dist\OSFY-PREMIUM\" >nul
        xcopy /E /I /Q "public" "dist\OSFY-PREMIUM\public" >nul
        mkdir "dist\OSFY-PREMIUM\license-system" 2>nul
        copy "license-system\*.js" "dist\OSFY-PREMIUM\license-system\" >nul
        copy "telas.json" "dist\OSFY-PREMIUM\" >nul
        copy "config.json" "dist\OSFY-PREMIUM\" >nul
        copy "base-conhecimento.json" "dist\OSFY-PREMIUM\" >nul
        copy "planos-config.json" "dist\OSFY-PREMIUM\" >nul
        echo {"plano":"PREMIUM","maxProdutos":-1} > "dist\OSFY-PREMIUM\plano.json"
        echo  PREMIUM.exe OK!
    )
    echo  Instalador...
    %ISCC% "instalador-premium.iss"
    goto MOSTRAR
)

if "%opcao%"=="4" (
    echo  Compilando GERADOR...
    pkg license-system/license-generator-planos.js --targets node18-win-x64 --output "dist/GERADOR-LICENCAS-OSFY.exe"
    if exist "dist\GERADOR-LICENCAS-OSFY.exe" (
        if exist "dist\GERADOR-LICENCAS" rmdir /s /q "dist\GERADOR-LICENCAS"
        mkdir "dist\GERADOR-LICENCAS"
        move "dist\GERADOR-LICENCAS-OSFY.exe" "dist\GERADOR-LICENCAS\" >nul
        copy "planos-config.json" "dist\GERADOR-LICENCAS\" >nul
        echo  GERADOR.exe OK!
    )
    echo  Instalador...
    %ISCC% "instalador-gerador.iss"
    goto MOSTRAR
)

echo  Opcao invalida!
pause
exit

:MOSTRAR
echo.
echo  ========================================================
echo.
echo  ARQUIVOS NA PASTA dist\:
echo.
dir "dist" /b
echo.
echo  ========================================================
echo.
pause
