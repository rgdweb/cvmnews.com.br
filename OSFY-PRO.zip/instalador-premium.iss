; ============================================
; OSFY PREMIUM - Script do Instalador
; ============================================

#define MyAppName "OSFY"
#define MyAppVersion "2.5"
#define MyAppPlan "PREMIUM"
#define MyAppExeName "OSFY-PREMIUM.exe"

[Setup]
AppId={{OSFY-PREMIUM-2024-001}
AppName={#MyAppName} {#MyAppPlan}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion} - {#MyAppPlan}
DefaultDirName={autopf}\OSFY-Premium
DefaultGroupName=OSFY
AllowNoIcons=yes
OutputDir=dist
OutputBaseFilename=OSFY-PREMIUM-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\{#MyAppExeName}

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
Source: "dist\OSFY-PREMIUM\OSFY-PREMIUM.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-PREMIUM\public\*"; DestDir: "{app}\public"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "dist\OSFY-PREMIUM\license-system\*"; DestDir: "{app}\license-system"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "dist\OSFY-PREMIUM\telas.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-PREMIUM\config.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-PREMIUM\base-conhecimento.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-PREMIUM\planos-config.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "dist\OSFY-PREMIUM\plano.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\OSFY Premium"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\OSFY Premium"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,OSFY}"; Flags: nowait postinstall skipifsilent

[Code]
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
    CreateDir(ExpandConstant('{app}\backups'));
end;
