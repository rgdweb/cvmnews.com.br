/**
 * OSFY - Sistema de Criptografia
 * Criptografia AES-256 para proteção de dados de licença
 */

const crypto = require('crypto');

// Chave secreta do OSFY (32 bytes para AES-256)
// Esta chave NUNCA deve ser alterada após licenças emitidas
const SECRET_KEY = crypto.createHash('sha256').update('OSFY-LICENSE-SECRET-KEY-2024').digest();
const IV_LENGTH = 16; // AES block size

/**
 * Criptografa dados usando AES-256-CBC
 * @param {object|string} data - Dados a serem criptografados
 * @returns {string} - Dados criptografados em base64
 */
function encrypt(data) {
    try {
        const text = typeof data === 'object' ? JSON.stringify(data) : String(data);
        const iv = crypto.randomBytes(IV_LENGTH);
        const cipher = crypto.createCipheriv('aes-256-cbc', SECRET_KEY, iv);
        
        let encrypted = cipher.update(text, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        
        // Combina IV + dados criptografados
        const result = iv.toString('hex') + ':' + encrypted;
        
        return Buffer.from(result).toString('base64');
    } catch (e) {
        console.error('Erro ao criptografar:', e.message);
        return null;
    }
}

/**
 * Descriptografa dados usando AES-256-CBC
 * @param {string} encryptedData - Dados criptografados em base64
 * @returns {object|string|null} - Dados originais
 */
function decrypt(encryptedData) {
    try {
        const decoded = Buffer.from(encryptedData, 'base64').toString('utf8');
        const parts = decoded.split(':');
        
        if (parts.length !== 2) {
            return null;
        }
        
        const iv = Buffer.from(parts[0], 'hex');
        const encrypted = parts[1];
        
        const decipher = crypto.createDecipheriv('aes-256-cbc', SECRET_KEY, iv);
        
        let decrypted = decipher.update(encrypted, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        
        // Tenta parsear como JSON
        try {
            return JSON.parse(decrypted);
        } catch {
            return decrypted;
        }
    } catch (e) {
        console.error('Erro ao descriptografar:', e.message);
        return null;
    }
}

/**
 * Gera um hash SHA256 de uma string
 * @param {string} text - Texto para hash
 * @returns {string} - Hash em hexadecimal
 */
function hash(text) {
    return crypto.createHash('sha256').update(text).digest('hex');
}

/**
 * Verifica se um hash corresponde ao texto
 * @param {string} text - Texto original
 * @param {string} hashedValue - Hash para comparação
 * @returns {boolean}
 */
function verifyHash(text, hashedValue) {
    return hash(text) === hashedValue;
}

/**
 * Gera uma chave de licença formatada
 * @param {string} requestCode - Código de solicitação
 * @param {string} hardwareId - ID do hardware
 * @returns {string} - Chave de licença formatada
 */
function generateLicenseKey(requestCode, hardwareId) {
    const combined = requestCode + hardwareId + Date.now().toString();
    const licenseHash = crypto.createHash('sha256')
        .update(combined + '-OSFY-LICENSE')
        .digest('hex')
        .substring(0, 24)
        .toUpperCase();
    
    // Formato: LICENSE-XXXX-XXXX-XXXX-XXXX-XXXX
    const formatted = licenseHash.match(/.{1,4}/g).join('-');
    
    return `LICENSE-${formatted}`;
}

module.exports = {
    encrypt,
    decrypt,
    hash,
    verifyHash,
    generateLicenseKey
};
