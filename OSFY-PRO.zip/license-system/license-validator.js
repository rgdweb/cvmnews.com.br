/**
 * OSFY - Validador de Licenca
 * Verifica se o sistema esta devidamente licenciado
 * COM PROTECAO CONTRA BURLA DO TRIAL
 * COM VALIDACAO DE CPF (INTRANSFERIVEL)
 * COM VALIDACAO DE FEATURES POR PLANO
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const hardwareId = require('./hardware-id');

// =====================================
// CONFIGURACOES
// =====================================
const LICENSE_FILE = path.join(__dirname, '..', 'license.enc');
const TRIAL_FILE = path.join(__dirname, '..', '.trial');
const TRIAL_REGISTRY = path.join(__dirname, '..', 'node_modules', '.osfy-registry');
const PLANOS_FILE = path.join(__dirname, '..', 'planos-config.json');
const SECRET_KEY = crypto.createHash('sha256').update('OSFY-LICENSE-SECRET-KEY-2024').digest();
const TRIAL_DAYS = 7;

// =====================================
// STATUS DE LICENCA
// =====================================
const LICENSE_STATUS = {
    VALID: 'valid',
    TRIAL: 'trial',
    TRIAL_EXPIRED: 'trial_expired',
    TRIAL_TAMPERED: 'trial_tampered',
    INVALID: 'invalid',
    EXPIRED: 'expired',
    HARDWARE_MISMATCH: 'hardware_mismatch',
    CPF_MISMATCH: 'cpf_mismatch',
    NOT_FOUND: 'not_found',
    CORRUPTED: 'corrupted'
};

// =====================================
// FEATURES PADRAO POR PLANO
// =====================================
function getPlanFeatures(planId) {
    try {
        if (fs.existsSync(PLANOS_FILE)) {
            const config = JSON.parse(fs.readFileSync(PLANOS_FILE, 'utf8'));
            if (config.planos && config.planos[planId]) {
                return config.planos[planId].features;
            }
        }
    } catch (e) {}
    
    // Features padrao caso nao encontre config
    const defaultFeatures = {
        BASICO: {
            maxProdutos: 100,
            maxEmpresas: 1,
            relatorios: false,
            modoTeste: false,
            exportarCSV: false,
            backupAuto: false,
            suporte: 'email',
            multiEmpresa: false,
            apiPersonalizada: false
        },
        PRO: {
            maxProdutos: -1,
            maxEmpresas: 1,
            relatorios: true,
            modoTeste: true,
            exportarCSV: true,
            backupAuto: false,
            suporte: 'whatsapp',
            multiEmpresa: false,
            apiPersonalizada: false
        },
        PREMIUM: {
            maxProdutos: -1,
            maxEmpresas: 999,
            relatorios: true,
            modoTeste: true,
            exportarCSV: true,
            backupAuto: true,
            suporte: 'prioritario',
            multiEmpresa: true,
            apiPersonalizada: true
        }
    };
    
    return defaultFeatures[planId] || defaultFeatures.BASICO;
}

// =====================================
// FUNCOES DE TRIAL SEGURO
// =====================================

function generateTrialKey() {
    const hwId = hardwareId.generateHardwareId();
    return crypto.createHash('sha256').update('TRIAL-' + hwId + '-OSFY').digest('hex').substring(0, 32);
}

function getHiddenRegistry() {
    try {
        if (fs.existsSync(TRIAL_REGISTRY)) {
            const data = fs.readFileSync(TRIAL_REGISTRY, 'utf8');
            return JSON.parse(data);
        }
        
        if (process.platform === 'win32') {
            const { execSync } = require('child_process');
            try {
                const result = execSync('reg query "HKCU\\Software\\OSFY" /v TrialStart 2>nul', { encoding: 'utf8' });
                const match = result.match(/TrialStart\s+REG_SZ\s+(.+)/);
                if (match) {
                    return {
                        startDate: match[1].trim(),
                        hardwareKey: generateTrialKey(),
                        fromRegistry: true
                    };
                }
            } catch (e) {}
        }
        
        return null;
    } catch (e) {
        return null;
    }
}

function saveHiddenRegistry(startDate) {
    try {
        const data = {
            startDate: startDate,
            hardwareKey: generateTrialKey(),
            version: '1.0'
        };
        
        const nodeModulesPath = path.join(__dirname, '..');
        const nodeModulesDir = path.join(nodeModulesPath, 'node_modules');
        if (fs.existsSync(nodeModulesDir)) {
            fs.writeFileSync(TRIAL_REGISTRY, JSON.stringify(data));
        }
        
        if (process.platform === 'win32') {
            try {
                const { execSync } = require('child_process');
                execSync(`reg add "HKCU\\Software\\OSFY" /v TrialStart /t REG_SZ /d "${startDate}" /f`, { stdio: 'ignore' });
                execSync(`reg add "HKCU\\Software\\OSFY" /v TrialHW /t REG_SZ /d "${data.hardwareKey}" /f`, { stdio: 'ignore' });
            } catch (e) {}
        }
        
        return true;
    } catch (e) {
        return false;
    }
}

function checkTrial() {
    try {
        const currentHwKey = generateTrialKey();
        const now = new Date();
        
        const hiddenRegistry = getHiddenRegistry();
        
        let trialFile = null;
        if (fs.existsSync(TRIAL_FILE)) {
            trialFile = JSON.parse(fs.readFileSync(TRIAL_FILE, 'utf8'));
        }
        
        if (hiddenRegistry && !trialFile) {
            if (hiddenRegistry.hardwareKey === currentHwKey) {
                const startDate = new Date(hiddenRegistry.startDate);
                const daysPassed = Math.floor((now - startDate) / (1000 * 60 * 60 * 24));
                
                if (daysPassed >= TRIAL_DAYS) {
                    return {
                        status: LICENSE_STATUS.TRIAL_EXPIRED,
                        daysRemaining: 0,
                        message: 'Trial expirado. Entre em contato para ativar.'
                    };
                }
                
                fs.writeFileSync(TRIAL_FILE, JSON.stringify({
                    startDate: hiddenRegistry.startDate,
                    hardwareId: currentHwKey
                }, null, 2));
                
                return {
                    status: LICENSE_STATUS.TRIAL,
                    daysRemaining: TRIAL_DAYS - daysPassed,
                    startDate: hiddenRegistry.startDate,
                    warning: 'Tentativa de burla detectada. Trial continua da onde parou.'
                };
            }
        }
        
        if (hiddenRegistry && trialFile) {
            const hiddenDate = new Date(hiddenRegistry.startDate).getTime();
            const fileDate = new Date(trialFile.startDate).getTime();
            
            if (Math.abs(hiddenDate - fileDate) > 3600000) {
                const oldestDate = hiddenDate < fileDate ? hiddenRegistry.startDate : trialFile.startDate;
                const startDate = new Date(oldestDate);
                const daysPassed = Math.floor((now - startDate) / (1000 * 60 * 60 * 24));
                
                if (daysPassed >= TRIAL_DAYS) {
                    return {
                        status: LICENSE_STATUS.TRIAL_EXPIRED,
                        daysRemaining: 0,
                        message: 'Trial expirado.'
                    };
                }
                
                return {
                    status: LICENSE_STATUS.TRIAL,
                    daysRemaining: TRIAL_DAYS - daysPassed,
                    startDate: oldestDate,
                    warning: 'Data do trial modificada. Sistema corrigido automaticamente.'
                };
            }
            
            if (trialFile.hardwareId && trialFile.hardwareId !== currentHwKey) {
                return {
                    status: LICENSE_STATUS.HARDWARE_MISMATCH,
                    message: 'Trial iniciado em outro computador. Nao e permitido transferir.'
                };
            }
            
            const startDate = new Date(trialFile.startDate);
            const daysPassed = Math.floor((now - startDate) / (1000 * 60 * 60 * 24));
            
            if (daysPassed < TRIAL_DAYS) {
                return {
                    status: LICENSE_STATUS.TRIAL,
                    daysRemaining: TRIAL_DAYS - daysPassed,
                    startDate: trialFile.startDate,
                    // Trial tem features do BASICO
                    plano: 'TRIAL',
                    planoNome: 'Trial',
                    features: {
                        maxProdutos: 20,
                        maxEmpresas: 1,
                        relatorios: false,
                        modoTeste: false,
                        exportarCSV: false,
                        backupAuto: false,
                        suporte: 'nenhum',
                        multiEmpresa: false,
                        apiPersonalizada: false
                    }
                };
            } else {
                return {
                    status: LICENSE_STATUS.TRIAL_EXPIRED,
                    daysRemaining: 0
                };
            }
        }
        
        const startDate = now.toISOString();
        
        const trialData = {
            startDate: startDate,
            hardwareId: currentHwKey
        };
        fs.writeFileSync(TRIAL_FILE, JSON.stringify(trialData, null, 2));
        
        saveHiddenRegistry(startDate);
        
        return {
            status: LICENSE_STATUS.TRIAL,
            daysRemaining: TRIAL_DAYS,
            startDate: startDate,
            isFirstRun: true,
            plano: 'TRIAL',
            planoNome: 'Trial',
            features: {
                maxProdutos: 20,
                maxEmpresas: 1,
                relatorios: false,
                modoTeste: false,
                exportarCSV: false,
                backupAuto: false,
                suporte: 'nenhum',
                multiEmpresa: false,
                apiPersonalizada: false
            }
        };
        
    } catch (e) {
        return {
            status: LICENSE_STATUS.CORRUPTED,
            error: e.message
        };
    }
}

function clearTrial() {
    try {
        if (fs.existsSync(TRIAL_FILE)) {
            fs.unlinkSync(TRIAL_FILE);
        }
        if (fs.existsSync(TRIAL_REGISTRY)) {
            fs.unlinkSync(TRIAL_REGISTRY);
        }
        
        if (process.platform === 'win32') {
            try {
                const { execSync } = require('child_process');
                execSync('reg delete "HKCU\\Software\\OSFY" /f 2>nul', { stdio: 'ignore' });
            } catch (e) {}
        }
    } catch (e) {}
}

// =====================================
// FUNCOES DE LICENCA
// =====================================

function decryptLicense() {
    try {
        if (!fs.existsSync(LICENSE_FILE)) {
            return null;
        }
        
        const encryptedData = fs.readFileSync(LICENSE_FILE, 'utf8');
        const decoded = Buffer.from(encryptedData, 'base64').toString('utf8');
        const parts = decoded.split(':');
        
        if (parts.length !== 2) {
            return null;
        }
        
        const iv = Buffer.from(parts[0], 'hex');
        const encrypted = parts[1];
        
        const decipher = crypto.createDecipheriv('aes-256-cbc', SECRET_KEY, iv);
        
        let decrypted = decipher.update(encrypted, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        
        return JSON.parse(decrypted);
    } catch (e) {
        return null;
    }
}

function verifySignature(licenseData) {
    try {
        const signature = licenseData.signature;
        const dataToVerify = { ...licenseData };
        delete dataToVerify.signature;
        
        const expectedSignature = crypto.createHmac('sha256', SECRET_KEY)
            .update(JSON.stringify(dataToVerify))
            .digest('hex');
        
        return signature === expectedSignature;
    } catch (e) {
        return false;
    }
}

function isExpired(expiresAt) {
    try {
        return new Date() > new Date(expiresAt);
    } catch (e) {
        return true;
    }
}

function validateCPF(licenseData) {
    try {
        if (!licenseData.clientCPF && !licenseData.clientCPFHash) {
            return { valid: true, reason: 'Licenca antiga (sem CPF)' };
        }
        
        if (!licenseData.clientCPF) {
            return { valid: false, reason: 'CPF nao encontrado na licenca' };
        }
        
        const cpfHash = crypto.createHash('sha256')
            .update(licenseData.clientCPF.replace(/[^\d]/g, ''))
            .digest('hex')
            .substring(0, 16);
        
        if (licenseData.clientCPFHash && licenseData.clientCPFHash !== cpfHash) {
            return { valid: false, reason: 'Hash do CPF nao corresponde' };
        }
        
        return { valid: true, cpf: licenseData.clientCPF };
    } catch (e) {
        return { valid: false, reason: 'Erro ao validar CPF' };
    }
}

/**
 * Valida a licenca completa com FEATURES
 */
function validateLicense() {
    const licenseData = decryptLicense();
    
    if (!licenseData) {
        return checkTrial();
    }
    
    if (!verifySignature(licenseData)) {
        return {
            status: LICENSE_STATUS.CORRUPTED,
            error: 'Assinatura invalida'
        };
    }
    
    if (isExpired(licenseData.expiresAt)) {
        return {
            status: LICENSE_STATUS.EXPIRED,
            expiresAt: licenseData.expiresAt,
            clientName: licenseData.clientName
        };
    }
    
    const currentHardwareId = hardwareId.generateHardwareId();
    const currentRequestCode = hardwareId.generateRequestCode();
    
    if (licenseData.requestCode && licenseData.requestCode !== currentRequestCode) {
        return {
            status: LICENSE_STATUS.HARDWARE_MISMATCH,
            error: 'Hardware diferente do cadastrado',
            expectedRequestCode: licenseData.requestCode,
            currentRequestCode: currentRequestCode
        };
    }
    
    const cpfValidation = validateCPF(licenseData);
    if (!cpfValidation.valid) {
        return {
            status: LICENSE_STATUS.CPF_MISMATCH,
            error: cpfValidation.reason
        };
    }
    
    // =====================================
    // NOVO: Obter features do plano
    // =====================================
    const planId = licenseData.plano || 'BASICO';
    const features = getPlanFeatures(planId);
    
    // Se a licenca tem recursos proprios (gerados pelo gerador), usa eles
    // Senao usa os do planos-config.json
    const finalFeatures = {
        maxProdutos: licenseData.maxProdutos ?? features.maxProdutos,
        maxEmpresas: licenseData.maxEmpresas ?? features.maxEmpresas ?? (features.multiEmpresa ? 999 : 1),
        relatorios: licenseData.recursos?.relatorios ?? features.relatorios,
        modoTeste: licenseData.recursos?.modoTeste ?? features.modoTeste,
        exportarCSV: licenseData.recursos?.exportarCSV ?? features.exportarCSV,
        backupAuto: licenseData.recursos?.backupAuto ?? features.backupAuto,
        suporte: features.suporte || 'email',
        multiEmpresa: licenseData.recursos?.multiEmpresa ?? features.multiEmpresa,
        apiPersonalizada: licenseData.recursos?.apiPersonalizada ?? features.apiPersonalizada
    };
    
    return {
        status: LICENSE_STATUS.VALID,
        clientName: licenseData.clientName,
        clientCPF: licenseData.clientCPF ? formatarCPF(licenseData.clientCPF) : null,
        transferLock: licenseData.transferLock || false,
        expiresAt: licenseData.expiresAt,
        createdAt: licenseData.createdAt,
        daysRemaining: Math.floor((new Date(licenseData.expiresAt) - new Date()) / (1000 * 60 * 60 * 24)),
        version: licenseData.version || '1.0',
        // NOVO: Plano e Features
        plano: planId,
        planoNome: licenseData.planoNome || planId,
        periodo: licenseData.periodo || 'ANUAL',
        features: finalFeatures
    };
}

function formatarCPF(cpf) {
    if (!cpf) return null;
    cpf = cpf.replace(/[^\d]/g, '');
    if (cpf.length !== 11) return cpf;
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}

function saveLicense(activationKey) {
    try {
        if (!activationKey || !activationKey.startsWith('OSFY-')) {
            return {
                success: false,
                error: 'Formato de chave invalido'
            };
        }
        
        const requestCode = hardwareId.generateRequestCode();
        const currentHardwareId = hardwareId.generateHardwareId();
        
        const now = new Date();
        const expiresAt = new Date(now.getTime() + (365 * 24 * 60 * 60 * 1000));
        
        const licenseData = {
            requestCode: requestCode,
            activationKey: activationKey,
            hardwareId: currentHardwareId,
            clientName: 'Cliente OSFY',
            createdAt: now.toISOString(),
            expiresAt: expiresAt.toISOString(),
            version: '2.5',
            plano: 'BASICO',
            planoNome: 'Básico'
        };
        
        const signature = crypto.createHmac('sha256', SECRET_KEY)
            .update(JSON.stringify(licenseData))
            .digest('hex');
        
        licenseData.signature = signature;
        
        const iv = crypto.randomBytes(16);
        const cipher = crypto.createCipheriv('aes-256-cbc', SECRET_KEY, iv);
        
        let encrypted = cipher.update(JSON.stringify(licenseData), 'utf8', 'hex');
        encrypted += cipher.final('hex');
        
        const result = iv.toString('hex') + ':' + encrypted;
        const encoded = Buffer.from(result).toString('base64');
        
        fs.writeFileSync(LICENSE_FILE, encoded);
        
        clearTrial();
        
        return {
            success: true,
            message: 'Licenca ativada com sucesso!'
        };
    } catch (e) {
        return {
            success: false,
            error: e.message
        };
    }
}

function importLicense(encryptedLicense) {
    try {
        if (!encryptedLicense || encryptedLicense.length < 50) {
            return {
                success: false,
                error: 'Licenca invalida'
            };
        }
        
        const tempFile = LICENSE_FILE + '.temp';
        fs.writeFileSync(tempFile, encryptedLicense);
        
        const oldData = fs.existsSync(LICENSE_FILE) ? fs.readFileSync(LICENSE_FILE, 'utf8') : null;
        
        fs.writeFileSync(LICENSE_FILE, encryptedLicense);
        
        const validation = validateLicense();
        
        if (validation.status === LICENSE_STATUS.HARDWARE_MISMATCH) {
            fs.unlinkSync(LICENSE_FILE);
            if (oldData) fs.writeFileSync(LICENSE_FILE, oldData);
            return {
                success: false,
                error: 'Esta licenca foi gerada para outro computador!'
            };
        }
        
        if (validation.status === LICENSE_STATUS.CPF_MISMATCH) {
            fs.unlinkSync(LICENSE_FILE);
            if (oldData) fs.writeFileSync(LICENSE_FILE, oldData);
            return {
                success: false,
                error: 'CPF nao corresponde ao cadastrado na licenca!'
            };
        }
        
        if (validation.status === LICENSE_STATUS.VALID) {
            clearTrial();
            if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            
            return {
                success: true,
                message: 'Licenca ativada com sucesso!',
                validation: validation
            };
        }
        
        if (oldData) fs.writeFileSync(LICENSE_FILE, oldData);
        else fs.unlinkSync(LICENSE_FILE);
        
        return {
            success: false,
            error: 'Licenca invalida ou corrompida',
            status: validation.status
        };
    } catch (e) {
        return {
            success: false,
            error: e.message
        };
    }
}

function getActivationInfo() {
    return {
        requestCode: hardwareId.generateRequestCode(),
        hardwareId: hardwareId.generateHardwareId(),
        hardwareInfo: hardwareId.getHardwareInfo()
    };
}

function removeLicense() {
    try {
        if (fs.existsSync(LICENSE_FILE)) {
            fs.unlinkSync(LICENSE_FILE);
        }
        return { success: true };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

/**
 * Verifica se uma feature esta disponivel no plano
 */
function hasFeature(featureName) {
    const validation = validateLicense();
    if (validation.status !== LICENSE_STATUS.VALID && validation.status !== LICENSE_STATUS.TRIAL) {
        return false;
    }
    return validation.features?.[featureName] === true;
}

/**
 * Verifica limite de produtos
 */
function checkProductLimit(currentCount) {
    const validation = validateLicense();
    if (validation.status !== LICENSE_STATUS.VALID && validation.status !== LICENSE_STATUS.TRIAL) {
        return { allowed: false, reason: 'Licenca invalida' };
    }
    
    const maxProdutos = validation.features?.maxProdutos || 100;
    if (maxProdutos === -1) return { allowed: true, unlimited: true };
    
    return {
        allowed: currentCount < maxProdutos,
        current: currentCount,
        max: maxProdutos,
        remaining: Math.max(0, maxProdutos - currentCount)
    };
}

/**
 * Verifica limite de empresas
 */
function checkEmpresaLimit(currentCount) {
    const validation = validateLicense();
    if (validation.status !== LICENSE_STATUS.VALID && validation.status !== LICENSE_STATUS.TRIAL) {
        return { allowed: false, reason: 'Licenca invalida' };
    }
    
    const maxEmpresas = validation.features?.maxEmpresas || 1;
    if (maxEmpresas === 999 || maxEmpresas === -1) return { allowed: true, unlimited: true };
    
    return {
        allowed: currentCount < maxEmpresas,
        current: currentCount,
        max: maxEmpresas,
        remaining: Math.max(0, maxEmpresas - currentCount)
    };
}

// =====================================
// EXPORTS
// =====================================

module.exports = {
    LICENSE_STATUS,
    validateLicense,
    saveLicense,
    importLicense,
    getActivationInfo,
    removeLicense,
    clearTrial,
    checkTrial,
    formatarCPF,
    getPlanFeatures,
    hasFeature,
    checkProductLimit,
    checkEmpresaLimit
};
