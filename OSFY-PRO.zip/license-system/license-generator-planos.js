#!/usr/bin/env node
/**
 * OSFY - Gerador de Licencas com PLANOS
 * USE APENAS O VENDEDOR - NAO DISTRIBUIR!
 * 
 * Uso: node license-generator-planos.js
 * 
 * Planos: BASICO, PRO, PREMIUM
 * Periodos: MENSAL, ANUAL, VITALICIO
 * Inclui CPF do cliente para licenca intransferivel
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

// =====================================
// CONFIGURACOES
// =====================================
const LICENSES_FILE = path.join(__dirname, '..', 'licenses-database.json');

// Chave secreta para validacao
const SECRET_KEY = crypto.createHash('sha256').update('OSFY-LICENSE-SECRET-KEY-2024').digest();

// =====================================
// PLANOS E PRECOS
// =====================================
const PLANOS = {
    BASICO: {
        nome: 'Básico',
        descricao: 'Ideal para começar',
        maxProdutos: 100,
        maxEmpresas: 1,
        recursos: {
            relatorios: false,
            modoTeste: false,
            exportarCSV: false,
            backupAuto: false,
            multiEmpresa: false
        },
        precos: {
            MENSAL: { valor: 79, dias: 30 },
            ANUAL: { valor: 697, dias: 365 }
        }
    },
    PRO: {
        nome: 'Pro',
        descricao: 'Para negócios em crescimento',
        maxProdutos: -1,
        maxEmpresas: 1,
        recursos: {
            relatorios: true,
            modoTeste: true,
            exportarCSV: true,
            backupAuto: false,
            multiEmpresa: false
        },
        precos: {
            MENSAL: { valor: 149, dias: 30 },
            ANUAL: { valor: 1297, dias: 365 }
        }
    },
    PREMIUM: {
        nome: 'Premium',
        descricao: 'Recursos completos + Multi-empresa',
        maxProdutos: -1,
        maxEmpresas: 999,
        recursos: {
            relatorios: true,
            modoTeste: true,
            exportarCSV: true,
            backupAuto: true,
            multiEmpresa: true
        },
        precos: {
            MENSAL: { valor: 247, dias: 30 },
            ANUAL: { valor: 1997, dias: 365 },
            VITALICIO: { valor: 2497, dias: 999999 }
        }
    }
};

// =====================================
// FUNCOES
// =====================================

/**
 * Valida CPF brasileiro
 */
function validarCPF(cpf) {
    cpf = cpf.replace(/[^\d]/g, '');
    if (cpf.length !== 11) return false;
    if (/^(\d)\1+$/.test(cpf)) return false;
    
    let soma = 0;
    for (let i = 0; i < 9; i++) {
        soma += parseInt(cpf.charAt(i)) * (10 - i);
    }
    let resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== parseInt(cpf.charAt(9))) return false;
    
    soma = 0;
    for (let i = 0; i < 10; i++) {
        soma += parseInt(cpf.charAt(i)) * (11 - i);
    }
    resto = (soma * 10) % 11;
    if (resto === 10 || resto === 11) resto = 0;
    if (resto !== parseInt(cpf.charAt(10))) return false;
    
    return true;
}

/**
 * Formata CPF (000.000.000-00)
 */
function formatarCPF(cpf) {
    cpf = cpf.replace(/[^\d]/g, '');
    if (cpf.length !== 11) return cpf;
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
}

/**
 * Gera a chave de ativacao
 */
function generateActivationKey(requestCode, cpf, plano, periodo) {
    const cleanCode = requestCode.replace('OSFY-', '').replace(/-/g, '');
    const cleanCPF = cpf.replace(/[^\d]/g, '');
    
    const hash = crypto.createHash('sha256')
        .update(cleanCode + '-' + cleanCPF + '-' + plano + '-' + periodo + '-OSFY-' + Date.now())
        .digest('hex')
        .substring(0, 16)
        .toUpperCase();
    
    const formatted = hash.match(/.{1,4}/g).join('-');
    
    return `OSFY-${plano.charAt(0)}${periodo.charAt(0)}-${formatted}`;
}

/**
 * Gera o conteudo da licenca
 */
function generateLicenseContent(requestCode, activationKey, clientName, clientCPF, plano, periodo) {
    const now = new Date();
    const planoConfig = PLANOS[plano];
    const precoConfig = planoConfig.precos[periodo];
    const expiresAt = new Date(now.getTime() + (precoConfig.dias * 24 * 60 * 60 * 1000));
    
    const cpfHash = crypto.createHash('sha256').update(clientCPF.replace(/[^\d]/g, '')).digest('hex').substring(0, 16);
    
    const licenseData = {
        requestCode: requestCode,
        activationKey: activationKey,
        clientName: clientName,
        clientCPF: clientCPF.replace(/[^\d]/g, ''),
        clientCPFHash: cpfHash,
        plano: plano,
        planoNome: planoConfig.nome,
        periodo: periodo,
        valorPago: precoConfig.valor,
        maxProdutos: planoConfig.maxProdutos,
        maxEmpresas: planoConfig.maxEmpresas,
        recursos: planoConfig.recursos,
        createdAt: now.toISOString(),
        expiresAt: expiresAt.toISOString(),
        daysValid: precoConfig.dias,
        version: '2.5',
        transferLock: true
    };
    
    const signature = crypto.createHmac('sha256', SECRET_KEY)
        .update(JSON.stringify(licenseData))
        .digest('hex');
    
    licenseData.signature = signature;
    
    return licenseData;
}

/**
 * Criptografa a licenca
 */
function encryptLicense(licenseData) {
    const text = JSON.stringify(licenseData);
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', SECRET_KEY, iv);
    
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    const result = iv.toString('hex') + ':' + encrypted;
    return Buffer.from(result).toString('base64');
}

/**
 * Carrega banco de dados de licencas
 */
function loadLicensesDatabase() {
    try {
        if (fs.existsSync(LICENSES_FILE)) {
            return JSON.parse(fs.readFileSync(LICENSES_FILE, 'utf8'));
        }
    } catch (e) {}
    return { licenses: [] };
}

/**
 * Salva licenca no banco de dados
 */
function saveLicense(requestCode, activationKey, clientName, clientCPF, plano, periodo, valor, encryptedLicense) {
    const db = loadLicensesDatabase();
    
    const existingIndex = db.licenses.findIndex(l => l.requestCode === requestCode);
    
    const record = {
        requestCode: requestCode,
        activationKey: activationKey,
        clientName: clientName,
        clientCPF: formatarCPF(clientCPF),
        plano: plano,
        periodo: periodo,
        valor: valor,
        createdAt: new Date().toISOString(),
        encrypted: encryptedLicense
    };
    
    if (existingIndex >= 0) {
        db.licenses[existingIndex] = record;
        console.log('   Licenca ATUALIZADA (ja existia uma para este codigo)');
    } else {
        db.licenses.push(record);
    }
    
    fs.writeFileSync(LICENSES_FILE, JSON.stringify(db, null, 2));
}

/**
 * Verifica se CPF ja esta cadastrado
 */
function checkCPFExists(cpf) {
    const db = loadLicensesDatabase();
    const cleanCPF = cpf.replace(/[^\d]/g, '');
    return db.licenses.find(l => l.clientCPF && l.clientCPF.replace(/[^\d]/g, '') === cleanCPF);
}

/**
 * Lista todas as licencas
 */
function listLicenses() {
    const db = loadLicensesDatabase();
    
    if (db.licenses.length === 0) {
        console.log('\n  Nenhuma licenca cadastrada.\n');
        return;
    }
    
    console.log('\n+================================================================+');
    console.log('|                    LICENCAS CADASTRADAS                        |');
    console.log('+================================================================+');
    
    db.licenses.forEach((lic, i) => {
        const planoBadge = `${lic.plano || 'N/A'}-${lic.periodo || 'N/A'}`;
        console.log(`| ${i + 1}. ${(lic.clientName || '').padEnd(20)} | ${planoBadge.padEnd(15)} |`);
        console.log(`|    CPF: ${lic.clientCPF || 'N/A'}`);
        console.log(`|    Codigo: ${lic.requestCode}`);
        console.log(`|    Chave: ${lic.activationKey}`);
        console.log(`|    Valor: R$ ${lic.valor || 'N/A'}`);
        console.log(`|    Criada: ${(lic.createdAt || '').split('T')[0]}`);
        console.log('+----------------------------------------------------------------+');
    });
    
    console.log('');
}

/**
 * Mostra tabela de precos
 */
function mostrarTabelaPrecos() {
    console.log('\n+================================================================+');
    console.log('|                    TABELA DE PRECOS OSFY                       |');
    console.log('+================================================================+');
    console.log('|                                                                |');
    console.log('|  PLANO      | MENSAL    | ANUAL     | VITALICIO  | RECURSOS   |');
    console.log('|-------------|-----------|-----------|------------|------------|');
    console.log('|  BASICO     | R$ 79/mes | R$ 697    | -          | 100 prod.  |');
    console.log('|  PRO        | R$ 149/mes| R$ 1.297  | -          | Ilimitado  |');
    console.log('|  PREMIUM    | R$ 247/mes| R$ 1.997  | R$ 2.497   | Tudo+Multi |');
    console.log('|                                                                |');
    console.log('+================================================================+');
    console.log('|  ANUAL: Economia de ~30% comparado ao mensal                   |');
    console.log('|  VITALICIO: Pague uma vez, use para sempre!                    |');
    console.log('|  PREMIUM: Suporte a multi-empresa (multiplas lojas)            |');
    console.log('+================================================================+');
    console.log('');
}

/**
 * Interface de linha de comando
 */
async function main() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    
    const question = (prompt) => new Promise(resolve => rl.question(prompt, resolve));
    
    console.log('\n');
    console.log('+================================================================+');
    console.log('|                                                                |');
    console.log('|            OSFY - GERADOR DE LICENCAS v2.5                     |');
    console.log('|              (COM PLANOS E PERIODOS)                           |');
    console.log('|                    (USO RESTRITO)                              |');
    console.log('|                                                                |');
    console.log('+================================================================+');
    console.log('\nOpcoes:');
    console.log('  1 - Gerar nova licenca');
    console.log('  2 - Listar licencas');
    console.log('  3 - Ver tabela de precos');
    console.log('  4 - Revogar licenca');
    console.log('  5 - Verificar CPF');
    console.log('  6 - Sair');
    console.log('');
    
    const opcao = await question('Escolha uma opcao: ');
    
    switch (opcao.trim()) {
        case '1': {
            console.log('\n--- GERAR NOVA LICENCA ---\n');
            
            // Selecionar plano
            console.log('Planos disponiveis:');
            console.log('  1 - BASICO (R$ 79/mes ou R$ 697/ano) - 100 produtos');
            console.log('  2 - PRO (R$ 149/mes ou R$ 1.297/ano) - Produtos ilimitados');
            console.log('  3 - PREMIUM (R$ 247/mes ou R$ 1.997/ano ou R$ 2.497 vitalicio) - Multi-empresa');
            console.log('');
            
            const planoOpcao = await question('Selecione o plano (1/2/3): ');
            let plano = 'BASICO';
            if (planoOpcao === '2') plano = 'PRO';
            if (planoOpcao === '3') plano = 'PREMIUM';
            
            const planoConfig = PLANOS[plano];
            console.log(`\nPlano selecionado: ${planoConfig.nome}`);
            
            // Selecionar periodo
            console.log('\nPeriodos disponiveis:');
            Object.entries(planoConfig.precos).forEach(([key, value], i) => {
                const label = key === 'MENSAL' ? 'mensal' : key === 'ANUAL' ? 'ano' : 'vitalicio';
                console.log(`  ${i + 1} - ${key} - R$ ${value.valor} (${value.dias === 999999 ? 'vitalicio' : value.dias + ' dias'})`);
            });
            
            const periodoOpcao = await question('\nSelecione o periodo (1/2/3): ');
            const periodos = Object.keys(planoConfig.precos);
            let periodo = periodos[0];
            if (periodoOpcao === '2' && periodos[1]) periodo = periodos[1];
            if (periodoOpcao === '3' && periodos[2]) periodo = periodos[2];
            
            const precoConfig = planoConfig.precos[periodo];
            console.log(`\nPeriodo: ${periodo}`);
            console.log(`Valor: R$ ${precoConfig.valor}`);
            console.log(`Validade: ${precoConfig.dias === 999999 ? 'VITALICIO' : precoConfig.dias + ' dias'}`);
            console.log('');
            
            const requestCode = await question('Codigo de Solicitacao (OSFY-XXXX-XXXX-XXXX): ');
            if (!requestCode.trim()) {
                console.log('  Codigo invalido!');
                rl.close();
                return main();
            }
            
            const clientName = await question('Nome do Cliente: ');
            if (!clientName.trim()) {
                console.log('  Nome invalido!');
                rl.close();
                return main();
            }
            
            const clientCPF = await question('CPF do Cliente (somente numeros): ');
            if (!clientCPF.trim()) {
                console.log('  CPF obrigatorio para licenca intransferivel!');
                rl.close();
                return main();
            }
            
            if (!validarCPF(clientCPF.trim())) {
                console.log('  CPF INVALIDO! Verifique e tente novamente.');
                rl.close();
                return main();
            }
            
            const cpfExistente = checkCPFExists(clientCPF.trim());
            if (cpfExistente) {
                console.log(`\n  ATENCAO: Este CPF ja possui licenca cadastrada!`);
                console.log(`  Cliente: ${cpfExistente.clientName}`);
                console.log(`  Plano: ${cpfExistente.plano || 'N/A'} - ${cpfExistente.periodo || 'N/A'}`);
                const continuar = await question('\nDeseja gerar outra licenca para este CPF? (s/n): ');
                if (continuar.toLowerCase() !== 's') {
                    rl.close();
                    return main();
                }
            }
            
            // Gera a chave de ativacao
            const activationKey = generateActivationKey(
                requestCode.trim().toUpperCase(),
                clientCPF.trim(),
                plano,
                periodo
            );
            
            // Gera o conteudo da licenca
            const licenseData = generateLicenseContent(
                requestCode.trim().toUpperCase(),
                activationKey,
                clientName.trim(),
                clientCPF.trim(),
                plano,
                periodo
            );
            
            // Criptografa
            const encryptedLicense = encryptLicense(licenseData);
            
            // Salva no banco de dados
            saveLicense(
                requestCode.trim().toUpperCase(),
                activationKey,
                clientName.trim(),
                clientCPF.trim(),
                plano,
                periodo,
                precoConfig.valor,
                encryptedLicense
            );
            
            const isVitalicio = periodo === 'VITALICIO';
            
            console.log('\n');
            console.log('+================================================================+');
            console.log('|                   LICENCA GERADA!                              |');
            console.log('+================================================================+');
            console.log(`| Plano: ${(planoConfig.nome + ' - ' + periodo).padEnd(54)}|`);
            console.log(`| Valor: ${('R$ ' + precoConfig.valor).padEnd(54)}|`);
            console.log(`| Cliente: ${(clientName).padEnd(52)}|`);
            console.log(`| CPF: ${(formatarCPF(clientCPF)).padEnd(56)}|`);
            console.log(`| Codigo: ${(requestCode).padEnd(54)}|`);
            console.log('+----------------------------------------------------------------+');
            console.log(`| CHAVE DE ATIVACAO:                                             |`);
            console.log(`| ${activationKey.padEnd(62)}|`);
            console.log('+----------------------------------------------------------------+');
            console.log(`| Validade: ${(isVitalicio ? 'VITALICIA' : precoConfig.dias + ' dias').padEnd(53)}|`);
            console.log(`| Max Produtos: ${(planoConfig.maxProdutos === -1 ? 'ILIMITADO' : planoConfig.maxProdutos).toString().padEnd(49)}|`);
            console.log(`| LICENCA INTRANSFERIVEL - Vinculada ao CPF                       |`);
            console.log('+================================================================+');
            console.log('\n Envie a CHAVE DE ATIVACAO para o cliente!\n');
            break;
        }
        
        case '2': {
            listLicenses();
            break;
        }
        
        case '3': {
            mostrarTabelaPrecos();
            break;
        }
        
        case '4': {
            console.log('\n--- REVOGAR LICENCA ---\n');
            listLicenses();
            
            const requestCode = await question('Digite o codigo de solicitacao para revogar: ');
            const db = loadLicensesDatabase();
            
            const index = db.licenses.findIndex(l => l.requestCode === requestCode.trim().toUpperCase());
            
            if (index >= 0) {
                const removed = db.licenses.splice(index, 1);
                fs.writeFileSync(LICENSES_FILE, JSON.stringify(db, null, 2));
                console.log(`\n  Licenca revogada: ${removed[0].clientName} (CPF: ${removed[0].clientCPF || 'N/A'})\n`);
            } else {
                console.log('\n  Licenca nao encontrada!\n');
            }
            break;
        }
        
        case '5': {
            console.log('\n--- VERIFICAR CPF ---\n');
            const cpfBusca = await question('Digite o CPF para verificar: ');
            const existente = checkCPFExists(cpfBusca.trim());
            
            if (existente) {
                console.log('\n  CPF ENCONTRADO:');
                console.log(`  Cliente: ${existente.clientName}`);
                console.log(`  Plano: ${existente.plano || 'N/A'} - ${existente.periodo || 'N/A'}`);
                console.log(`  Valor: R$ ${existente.valor || 'N/A'}`);
                console.log(`  Codigo: ${existente.requestCode}`);
                console.log(`  Chave: ${existente.activationKey}`);
                console.log(`  Criada: ${existente.createdAt}`);
            } else {
                console.log('\n  CPF nao cadastrado.\n');
            }
            break;
        }
        
        case '6': {
            console.log('\n  Ate logo!\n');
            rl.close();
            process.exit(0);
        }
        
        default: {
            console.log('\n  Opcao invalida!\n');
            break;
        }
    }
    
    rl.close();
    main();
}

// Executa
main();
