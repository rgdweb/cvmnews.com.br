/**
 * OSFY - Sistema de Identificação de Hardware
 * Gera um ID único baseado nas características do computador
 */

const os = require('os');
const crypto = require('crypto');
const { execSync } = require('child_process');

/**
 * Obtém o MAC Address da primeira interface de rede ativa
 */
function getMACAddress() {
    try {
        const interfaces = os.networkInterfaces();
        for (const name of Object.keys(interfaces)) {
            for (const iface of interfaces[name]) {
                // Pular interfaces internas e loopback
                if (!iface.internal && iface.mac && iface.mac !== '00:00:00:00:00:00') {
                    return iface.mac.toUpperCase();
                }
            }
        }
    } catch (e) {}
    return 'UNKNOWN-MAC';
}

/**
 * Obtém o Serial do disco rígido (Windows)
 */
function getDiskSerial() {
    try {
        // Windows
        if (process.platform === 'win32') {
            const output = execSync('wmic diskdrive get serialnumber', { encoding: 'utf8' });
            const lines = output.split('\n').filter(l => l.trim());
            if (lines.length > 1) {
                return lines[1].trim().toUpperCase();
            }
        }
        // Linux
        if (process.platform === 'linux') {
            const output = execSync('lsblk -o SERIAL -d -n | head -1', { encoding: 'utf8' });
            return output.trim().toUpperCase();
        }
    } catch (e) {}
    return 'UNKNOWN-DISK';
}

/**
 * Obtém o UUID da placa mãe (Windows)
 */
function getMotherboardUUID() {
    try {
        if (process.platform === 'win32') {
            const output = execSync('wmic csproduct get UUID', { encoding: 'utf8' });
            const lines = output.split('\n').filter(l => l.trim());
            if (lines.length > 1) {
                return lines[1].trim().toUpperCase();
            }
        }
        // Linux - usar machine-id
        const fs = require('fs');
        if (fs.existsSync('/etc/machine-id')) {
            return fs.readFileSync('/etc/machine-id', 'utf8').trim().toUpperCase();
        }
    } catch (e) {}
    return 'UNKNOWN-UUID';
}

/**
 * Obtém o hostname do computador
 */
function getHostname() {
    try {
        return os.hostname().toUpperCase();
    } catch (e) {
        return 'UNKNOWN-HOST';
    }
}

/**
 * Gera o ID de hardware combinando todas as informações
 * Retorna um código único de 32 caracteres
 */
function generateHardwareId() {
    const mac = getMACAddress();
    const disk = getDiskSerial();
    const uuid = getMotherboardUUID();
    const host = getHostname();

    // Combina todas as informações
    const combined = `${mac}|${disk}|${uuid}|${host}`;
    
    // Gera hash SHA256
    const hash = crypto.createHash('sha256').update(combined).digest('hex');
    
    // Retorna os primeiros 32 caracteres em grupos de 4
    const formatted = hash.substring(0, 32).toUpperCase().match(/.{1,4}/g).join('-');
    
    return formatted;
}

/**
 * Gera o código de solicitação de licença
 * Formato: OSFY-XXXX-XXXX-XXXX-XXXX
 */
function generateRequestCode() {
    const hardwareId = generateHardwareId();
    
    // Cria um hash do hardware ID para o código de solicitação
    const hash = crypto.createHash('sha256')
        .update(hardwareId + '-OSFY-REQUEST')
        .digest('hex')
        .substring(0, 16)
        .toUpperCase();
    
    const formatted = hash.match(/.{1,4}/g).join('-');
    
    return `OSFY-${formatted}`;
}

/**
 * Obtém informações detalhadas do hardware (para debug)
 */
function getHardwareInfo() {
    return {
        mac: getMACAddress(),
        disk: getDiskSerial(),
        uuid: getMotherboardUUID(),
        hostname: getHostname(),
        platform: process.platform,
        arch: process.arch,
        hardwareId: generateHardwareId(),
        requestCode: generateRequestCode()
    };
}

module.exports = {
    getMACAddress,
    getDiskSerial,
    getMotherboardUUID,
    getHostname,
    generateHardwareId,
    generateRequestCode,
    getHardwareInfo
};
