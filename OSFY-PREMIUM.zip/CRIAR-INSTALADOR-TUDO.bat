@echo off
chcp 65001 >nul
title OSFY - Criar Instaladores
color 0A

cd /d "%~dp0"

echo.
echo  ========================================================
echo.
echo            OSFY - CRIAR INSTALADORES
echo.
echo  ========================================================
echo.
echo  1 - BASICO    2 - PRO    3 - PREMIUM    4 - GERADOR    5 - TODOS
echo.
set /p opcao="Opcao: "

if not exist "dist" mkdir "dist"

set ISCC="C:\Program Files\Inno Setup 7\ISCC.exe"
if not exist %ISCC% set ISCC="C:\Program Files (x86)\Inno Setup 7\ISCC.exe"

echo.
echo  ========================================================

if "%opcao%"=="5" (
    echo.
    echo  Criando instalador BASICO...
    %ISCC% "instalador-basico.iss"
    echo.
    echo  Criando instalador PRO...
    %ISCC% "instalador-pro.iss"
    echo.
    echo  Criando instalador PREMIUM...
    %ISCC% "instalador-premium.iss"
    echo.
    echo  Criando instalador GERADOR...
    %ISCC% "instalador-gerador.iss"
    goto MOSTRAR
)

if "%opcao%"=="1" (
    echo.
    echo  Criando instalador BASICO...
    %ISCC% "instalador-basico.iss"
    goto MOSTRAR
)

if "%opcao%"=="2" (
    echo.
    echo  Criando instalador PRO...
    %ISCC% "instalador-pro.iss"
    goto MOSTRAR
)

if "%opcao%"=="3" (
    echo.
    echo  Criando instalador PREMIUM...
    %ISCC% "instalador-premium.iss"
    goto MOSTRAR
)

if "%opcao%"=="4" (
    echo.
    echo  Criando instalador GERADOR...
    %ISCC% "instalador-gerador.iss"
    goto MOSTRAR
)

echo  Opcao invalida!
pause
exit

:MOSTRAR
echo.
echo  ========================================================
echo.
echo  INSTALADORES CRIADOS NA PASTA dist\:
echo.
dir "dist\*.exe" /b 2>nul
echo.
echo  ========================================================
echo.
pause
