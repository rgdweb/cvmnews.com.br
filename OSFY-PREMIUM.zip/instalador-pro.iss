; ============================================
; OSFY PRO - Script do Instalador
; ============================================

#define MyAppName "OSFY"
#define MyAppVersion "2.5"
#define MyAppPlan "PRO"

[Setup]
AppId={{OSFY-PRO-2024-001}
AppName={#MyAppName} {#MyAppPlan}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion} - {#MyAppPlan}
DefaultDirName={autopf}\OSFY-Pro
DefaultGroupName=OSFY
AllowNoIcons=yes
OutputDir=dist
OutputBaseFilename=OSFY-PRO-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\INICIAR.bat

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
; Arquivos principais do servidor
Source: "server.js"; DestDir: "{app}"; Flags: ignoreversion
Source: "package.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "package-lock.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "config.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "telas.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "base-conhecimento.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "planos-config.json"; DestDir: "{app}"; Flags: ignoreversion

; Scripts de inicializacao (IMPORTANTE!)
Source: "INICIAR.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "INSTALAR.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "CONFIGURAR.bat"; DestDir: "{app}"; Flags: ignoreversion

; License system
Source: "license-system\*"; DestDir: "{app}\license-system"; Flags: ignoreversion recursesubdirs createallsubdirs

; Public (interface)
Source: "public\*"; DestDir: "{app}\public"; Flags: ignoreversion recursesubdirs createallsubdirs

; Documentacao
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "TABELA-PRECO-PLANOS.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "PASSO_A_PASSO.md"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\OSFY Pro - INICIAR"; Filename: "{app}\INICIAR.bat"; WorkingDir: "{app}"
Name: "{group}\OSFY Pro - Instalar Dependencias"; Filename: "{app}\INSTALAR.bat"; WorkingDir: "{app}"
Name: "{autodesktop}\OSFY Pro"; Filename: "{app}\INICIAR.bat"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\INICIAR.bat"; Description: "Iniciar OSFY Pro"; Flags: postinstall shellexec skipifsilent; WorkingDir: "{app}"

[Code]
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
    CreateDir(ExpandConstant('{app}\backups'));
end;
